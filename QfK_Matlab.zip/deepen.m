function [dopt,rhoopt,Omax,awardopt,Vopt]=deepen(eta,zeta,q,s,X, gridd,gridrho)
% Function that determines the optimal solution when deepening the
% knwoledge by bridging gaps given the cost sensitivity, the award sensitivity
% and the variance cutoff

%Inputs: 
%     cost sensitivity: eta
%     award sensitivity: zeta
%     variance sensitivity: q
%     interval length: X
%     gridsize (optional): grid
%     upper bound on reward likelihood: s
%Outputs:
%    optimal distance: doptd
%    optimal precision: rhooptd
%    resulting value: Omaxd

%check if grid is provided, otherwise use default 10


if nargin<5
    error('too few parameters: please specify (eta,zeta,q,X)')
elseif nargin<6
    warning('no grid values provided: using default of 10 for d and rho')
    gridd=10;
    gridrho=gridd;
elseif nargin <7
    gridrho=gridd;
    warning('no separate grid values provided: using the one provided for both d and rho')
end

%% Numerics
dmin=min(10e-7,X/2);
d=linspace(dmin,X/2,gridd); %Maximum length that can be optimal
rho=linspace(10e-7,1,gridrho);
d=repmat(d,length(rho),1); %d grows in columns
rho=repmat(rho',1,length(d(1,:))); %rho grows in rows

% Nullify potential complex values.
help1=max(X-d-4*q,0);
help2=max(d-4*q,0);
help3=max(X-4.*q,0);

V=(-2.*d.^2+2.*d.*X+sqrt(d).*help2.^(3/2)-sqrt(X).*help3.^(3/2)+sqrt(X-d).*help1.^(3/2))./(6.*q);

c=(erfinv(rho)).^2.*d.*(1-d./X);
likelihood=min((d.*(1-d./X))./s,1);
award=rho.*likelihood;
Obj=rho.*V + zeta.*award - eta.*c;

[~,rhoindex]=max(Obj,[],'linear');
rhoofd=rho(rhoindex);

[Omax,dmaxindex]=max(Obj(rhoindex));
dopt=d(1,dmaxindex);
rhoopt=rhoofd(dmaxindex);

awardopt=likelihood(rhoindex);
awardopt=awardopt(dmaxindex);
Vopt=V(rhoindex);
Vopt=Vopt(dmaxindex);
end