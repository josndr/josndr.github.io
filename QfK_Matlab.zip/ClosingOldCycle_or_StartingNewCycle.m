clear
close all

%% Description


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%               SHOULD THE PLANNER REMOVE KNOWLEDGE BLOCKADES?             %%
%  Here we compare 2 scenarios for the planner who faces a situation in    %%
%  with an open (short) cycle and is given the options to                  %%
%   - close it                                                             %%
%   - start another cycle instead                                          %%
%  for different levels of cost $\eta$ and discounting $\delta$            %%
%                                                                          %%
%  STRUCTURAL ASSUMPTIONS:                                                 %%
%                                                                          %%
%  1. Researchers are symmetric and base decisions only on                 %%
% current knowledge(stuck everywhere model)                                %%
%  2. Disclosure is costless                                               %%
%  3. The knowledge blockade comes from an unfinished _optimal_ research   %%
%  cycle (i.e. optimal moonshot)                                           %%
%  4. The available set of moonshots is such that they only cause short    %%
%  cycles                                                                  %%
%  5. Researchers myopically optimize otherwise taking eta into account and%%
%  are fully symmetric                                                     %%
%  6. The planner does not internalize the cost of research at all         %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Required
%The following functions should be within the path
%  expanding.m
%  deepen.m

%% Output

% We provide a map over the parameter space (eta,delta) depicting when 
% (a) removing the knowledge blockade is optimal
% (b) starting a new cycle is optimal
% (c) no cycles are optimal up front

% As a side product we provide the optimal moonshot as optd(i).
%% Inputs

% It uses the following default parameter for q (inconsequential for
% results)
    q=1;

% The cost parameter is consider for range
etaspace=linspace(0.01,4,50);

% Discounting is considered for range
deltaspace=linspace(1,0.4,50);


%gridsize for researcher choices
grid=500;


%% ||| Computations |||
%  vvv              vvv
% (DO NOT CHANGE UNLESS YOU KNOW WHAT YOU'RE DOING)

% Create parallel Pool
pool=gcp;

%create empty spaces;
optX = zeros(length(deltaspace),length(etaspace));
optd = optX; optrho = optX; benefit_closing = optX;
longrun_remove_knowledge_blockade = optX; longrun_new_cycle = optX; longrun_myopic_opt = optX; 
hatX=optX; longrun_cycle=optX; continuation_ladder=optX;rhoinfty=optX;


[E,D]=meshgrid(etaspace,deltaspace); %defined the grid to loop over

%% Calculating the different values
parfor i=1:numel(D) % loop over deltas and etas
    delta=D(i);
    eta=E(i);
    
        %% Determine optimal moonshot properties
        % maximize the benefits of moonshots in the range [2*q 8*q] which
        % comes from theory as ranges that a short-cycle moonshot never
        % would be outside of (see Proposition 3 in the paper)

        % Determine \hat{X}
        hatX(i)=fminsearch(@(X) hatXdiff(X,eta,q,grid),2*q);

        %Expanding results
        [~,rhoexp,Rpayoff_expanding,~,benefits_expand]=expanding(eta,0,q,1,grid,grid);
        rhoinfty(i)=rhoexp;

        % Long run value expanding ladder
        continuation_ladder=benefits_expand/(1-rhoexp*delta);
        
        %% Optimal Ex-ante moonshot
        %choose optX that guarantees a short cycle
        optX(i)=fminbnd(@(X) -(valueMS(eta,q,X,delta,grid)+rhoclosing(eta,q,X,grid)*delta*rhoexp*delta*continuation_ladder),hatX(i),8*q); 
        % determine researcher choices and benefit for the otpimal moonshot
        [optd(i),optrho(i),Rpayoff_deepen,~,benefit_closing(i)]=deepen(eta,0,q,1,optX(i),grid,grid);

        %% Optimal moonshot post failure
        %choose optX that guarantees a short cycle
        optXpostf(i)=fminbnd(@(X) -valueMS(eta,q,X,delta,grid),hatX(i),8*q); 
        % determine researcher choices and benefit for the otpimal moonshot
        [optdpostf(i),optrhopostf(i),Rpayoff_deepenpostf,~,benefit_closingpostf(i)]=deepen(eta,0,q,1,optXpostf(i),grid,grid);
       
        %% Determine long run values
        
        % invalidate if optimal moonshot is worse than myopic optimum
        longrun_myopic_opt(i)=3/2*q+ delta*rhoexp*continuation_ladder; %faileverywhere
        longrun_cycle(i)=valueMS(eta,q,optX(i),delta,grid)+optrho(i)*delta*rhoexp*delta*continuation_ladder;
        longrun_remove_knowledge_blockade(i)= benefit_closing(i)+ delta*rhoexp*continuation_ladder;
        longrun_new_cycle(i)=valueMS(eta,q,optXpostf(i),delta,grid);

          
end
%% Comparing these values
%%Plotting
CyclePreferred=longrun_cycle-longrun_myopic_opt;
FillingUpPreferred=longrun_remove_knowledge_blockade-longrun_new_cycle;
FillingUpPreferred=min(FillingUpPreferred,1);
FillingUpPreferredIfCyclePreferred=FillingUpPreferred;
FillingUpPreferredIfCyclePreferred(CyclePreferred<0)=nan;

colormap autumn
figure
surf(etaspace,deltaspace,CyclePreferred);
title('Is a Moonshot optimal?')
xlabel('\eta')
ylabel('\delta')
figure
surf(etaspace,deltaspace,FillingUpPreferred);
title('Is Filling Up optimal')
xlabel('\eta')
ylabel('\delta')
figure
surf(etaspace,deltaspace,FillingUpPreferredIfCyclePreferred);
title('Is it Optimal To Close The Cycle?')
xlabel('\eta')
ylabel('\delta')
colormap autumn
colorbar



%% Functions needed for computation

% function to extract the rho of closing a moonshot of X
function deephelp=rhoclosing(eta,q,X,grid)
    [~,deephelp]=deepen(eta,0,q,1,X,grid,grid);
end

% function to determine the value created by the moonshot
function longrun_value_MS=valueMS(eta,q,X,delta,grid) 
    benefitexpanding= (X - X.^2 / (6 * q)) + ... %benefit expansion
            (X > 4*q) .* (sqrt(X) .* (X - 4 * q)^(3/2)) / (6 * q);
    [d,rho,~,~,benefitdeepen]=deepen(eta,0,q,1,X,grid,grid); %benefit and parameters deepening
    if d<X/2-0.001 %exclude longer cycles
        longrun_value_MS=-inf;
    else %determine long-run value of a cycle
        longrun_value_MS= benefitexpanding+rho*delta*benefitdeepen;
    end
end

%function that determines the difference between expanding and deepening
%for a given X to determine hatX.
function absdifference=hatXdiff(X,eta,q,grid)
    [~,~,Rpayoffexp]=expanding(eta,0,q,1,grid,grid); %Expanding payoff R
    [~,~,Rpayoffdeep]=deepen(eta,0,q,1,X,grid,grid); % Deepening payoff R
    absdifference=abs(Rpayoffexp-Rpayoffdeep); %absolute difference
end