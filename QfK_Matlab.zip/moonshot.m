function [overallvalue,values,probabilities,scatt,rhos,Vs,X,rhoprod,d,rho,deep]=moonshot(eta,q,moonshot,delta,rounds,gridd,gridrho,rhos,Vs,create_tikz)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This functions takes the parameters as input and simulates an initial
% moonshot (starting at $\mathcal F_1=\{(0,y(0))\}$ and subsequent behavior.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% It takes as inputs
% eta: cost parameter
% q: value outside option DM
% moonshot: distance of the initial moonshot
% delta: discount factor DM
% rounds: How many rounds to simulate
% gridd, gridrho: respective grid sizes
% figures: predefined figures for comparison of rho and Vs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Dependencies:
% Requires functions expanding.m and deepen.m in the same folder
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% As outputs it creates
% 
% overallvalue: value created of the strategy
% values: per period values
% probabilities: per period likelihoods
% scatt: plott on discoveries
% rhos: plot on likelihoods
% Vs: plot on values
% X: areas created
% rhoprod: probability that science continues
% d: novelty created over time
% rho: per period probability of discovery
% deep: dummy whether research deepens (=1) or expands (=0)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%checking input and creating figures if needed
if nargin<10
    create_tikz=0;
end
if nargin<8
    rhos=figure('visible','off');
    hold on
    Vs=figure('visible','off');
    hold on
elseif nargin<9
    figure(rhos)
    hold on
    Vs=figure;
    hold on
else
    set(0, 'currentfigure', rhos);
    hold on
    set(0, 'currentfigure', Vs);
    hold on
end
if nargin<7
    warning('only 1 grid provided using it for both d and rho')
    gridrho=gridd;
end      
if nargin<6
    error('too few inputs')
end
% Checking whether this is a meaningful moonshot comparison
if moonshot<expanding(eta,0,q,1,gridd,gridrho)
    warning('you put the moonshot below what the agent would do anyways. Results have no meaning')
elseif moonshot<3*q
    warning('your moonshot is below the myopically optimal one. Most likely you can improve using moonshot=3q')
end

% check for heterogenous eta
if length(eta)>1
    warning('you submitted heterogenous etas: If you do not know what that means, please see the cod of the function')
    
%Determine if cycles needed
    if length(eta)>rounds
        warning('The eta vector is larger than the number of rounds. I will ignore the later rounds')
        etaspace=eta(1:rounds);
        
    elseif length(eta)==rounds
        etaspace=eta;
    else
        warning('the number of rounds is larger than the number of eta values. I will circle through')
        etaspace=repmat(eta,1,round(rounds/length(eta),0));
        etaspace=etaspace(1:rounds);
    end
else
    etaspace=repmat(eta,1,round(rounds/length(eta),0));
    etaspace=etaspace(1:rounds);
end       
       
    deltavector=(delta.^linspace(1,rounds,rounds))/delta;
    
    zeta=1000*etaspace(1); %set very high prize to guarantee d=moonshot in first round choice
    s=moonshot; %set moonshot target
    
   
    scatt=figure('visible','off'); %open figure

   
    % Initial vectors
    de=zeros(size(etaspace));
    rhoe=zeros(size(etaspace));
    Vexpand=zeros(size(etaspace));
    d=zeros(size(etaspace));
    V=zeros(size(etaspace));
    U=zeros(size(etaspace));
    deep=zeros(size(etaspace)); %create dummy  whether expand or deepen
    
    
    %%%
    %  Calculate Initial Moonshot outcome
    [de(1),rhoe(1),U(1),~,Vexpand(1)]=expanding(etaspace(1),zeta,q,s,gridd,gridrho);
    d(1)=de(1);
    rho(1)=1; % set initial discovery probability to 1

    X=d(1); %Store area
    V(1)=Vexpand(1); %Store Value of moonshot
    rhoprod(1)=rho(1); %store cummulative probability
    
    
    set(0, 'currentfigure', scatt);
    scatter(X,rounds, 'filled', 'b');
    hold on
    
    


    
    zeta=0; %Remove price for subsequent periods.
    
    for e=2:length(etaspace) %steps 2 until end of rounds
   
        % Calculate expanding outcome
        [de(e),rhoe(e),Uexpand,~,Vexpand(e)]=expanding(etaspace(e),zeta,q,s,gridd,gridrho);
        d(e)=de(e); %store distance preliminary
        rho(e)=rhoe(e); %store probability preliminary

        V(e)=Vexpand(e); %store value preliminary
        
        % Calculate deepening option (and compare)
        for x=1:length(X) %loop over existing areas
        % Calculate
         [dd(x),rhod(x),Ud(x),~,Vd(x)]=deepen(etaspace(e),zeta,q,s,X(x),gridd,gridrho);
        end
        if max(Ud)>Uexpand %compare among all and pick highest if better than expand
            deep(e)=1; %set dummy to 1 if deepen preferred to expanding
            [~,i]=max(Ud); %determine optimal area
            d(e)=dd(i); %store optimal distance
            rho(e)=rhod(i); %store optimal probability
            U(e)=Ud(i); %store optimal Utility
            V(e)=Vd(i); %store value created
            
            % replace old area with two new ones
            vectorX=length(X); 
            for x=0:vectorX-i
                X(vectorX-x+1)=X(vectorX-x);
            end
            X(i+1)=X(i)-d(e);
            X(i)=d(e);            
        else %if expand preferred
            X(length(X)+1)=d(e); %add new area
            U(e)=Uexpand; %store Utility (rest is as above)
        end
        %Scatter plot knowledge on R
        el=0;
        for x=1:length(X) %scatter plot
           el=el+X(x);
           set(0, 'currentfigure', scatt);
           scatter(el,rounds-e+1,'filled', 'r')
        end
        set(0, 'currentfigure', scatt);
        scatter(s,rounds-e+1,'filled','b') %Plot initial moonshot in different color
        rhoprod(e)=prod(rho); %probability of only successes until this point
        if create_tikz==1 %output picture if switch turned on
          matlab2tikz(sprintf('../Pictures/dynamic%d.tikz',round(s,0)),'relativeDataPath', '../Data', 'dataPath', '../Data', 'externalData', true,'showInfo', false,'width','\textwidth','standalone',true)
        end
    end
    
    
%     Plot success probabilities (conditional on reaching period) over time
    set(0, 'currentfigure', rhos);
    plot(linspace(1,rounds,rounds),rho)

    %Store continuation payoffs until eternity from now on (if sufficiently many rounds).
    if deep(end)==1
        warning('values do not describe real outcome because still in catching up phase. Consider increasing the period length')
    else
        V(end)= Vexpand(end)./(1-rho(end).*delta);
    end
    
    
    %Plot values created (conditional on success) over time
    set(0, 'currentfigure', Vs);
    plot(linspace(1,rounds,rounds),V)
    values=V; %store per period values
    probabilities=rhoprod; %store probability of reaching 

    valuevector=deltavector.*probabilities.*values; %Vector of discounted (both prob and discountfactor) values
    overallvalue=sum(valuevector); %Ex ante value created
end