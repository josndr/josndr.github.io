% This code plots the budget line for different Budgets. It takes the model 
% and the budget parameters as inputs and plots the relevant budget
% frontiers
%
% We calculate two budget sets. One for kappa low, one for kappa high
%
%%%%%%%%%%


clearvars
close all
addpath(genpath('Latex_templates'))


%%% Parameters model
s=[50];
zetabase=0;
q=1;
etabase=1;
gridd=500;
gridrho=800;

%%% Parameters budget
kappaspace=[7,14];
Kmin1=0.1;
Kmin2=1;
Kmax=6;
nocurves=30;
Kspacelow=linspace(Kmin1,Kmax,30);
Kspacehigh=linspace(Kmin2,Kmax,30);
Kspace=[Kspacelow Kspacehigh];
figcutoff=figure;

for es=1:length(kappaspace)
    kappa=kappaspace(es);
    %Testing Kspace
    i=1;
    while i<=length(Kspace)
        K=Kspace(i);
        if etabase-K/kappa<=0
            warning('You chose a too high budget such that one could eliminate cost  \n%s', ...
                'to get first best.  \n%s', ...
                'Will be capped the budget at the smallest such value')
            Kspace(Kspace>=K)=K;
            disp('New K vector:')
            Kspace
        elseif expanding(etabase,K,q,s,gridd,gridrho)>=4*q
            warning('You chose a too high budget that has the potential for too large d and is not covered by the proposition. The budget will be capped at the smallest that guarantees reasonable overshooting')
             Kspace(Kspace>=K)=Kspace(i-1);
             disp('New K vector:')
        Kspace
        end
        i=i+1;
    end

    % cost functions and their derivatives
    c= @(rho) erfinv(rho).^2; %cost of rho
    diffc=@(rho) pi.^(1/2).*exp(erfinv(rho).^2).*erfinv(rho); %derivative of c
    d2c=@(rho) (pi.*exp(2*erfinv(rho).^2))/2 + pi.*exp(2*erfinv(rho).^2).*erfinv(rho).^2; % second derivative of c;



    % Horizontal iso rho
    MRS= @(rho) (2*diffc(rho) - c(rho)/rho)*s;
    options = optimset('Display','off');
    boundrho=fsolve(@(rho) MRS(rho)-kappa,.9,options);

    [d0,rho0]=expanding(etabase,zetabase,q,s,gridd,gridrho);

    figure
    plot(rho0,d0)
    hold on 
    for i=1:length(Kspace)
        K=Kspace(i);
        %Polar rhos
        [d1,rho1]=expanding(etabase,zetabase+K,q,s,gridd,gridrho);
        [d2,rho2]=expanding(etabase-K/kappa,zetabase,q,s,gridd,gridrho);
        if d1==s
            return
        end
        polarmax=max(rho1,rho2); %candidate for maxrho
        polarmin=min(rho1,rho2); %candidate for minrho


        if K+s~=kappa*etabase %regular case

            if K+s>kappa*etabase
                minrho=max(boundrho,polarmin);
                maxrho=min(1,polarmax);
            else
                minrho=max(0,polarmin);
                maxrho=min(boundrho,polarmax);
            end
            rho=linspace(polarmin,polarmax,100);
            d=6.*q.*(K+s-kappa.*etabase).*(rho.*diffc(rho)-c(rho))./(2*s.*rho.*diffc(rho)-s.*c(rho)-kappa.*rho);
            plot(rho,d)
        else %specal case that budget line=isorho curve.
            rho=boundrho;
            dmax=expanding(etabase-K/kappa,0,q,s,gridd,gridrho);
            dmin=expanding(etabase,K,q,s,gridd,gridrho);
            line([rho,rho],[dmin,dmax])
        end
    end
%     sprintf('feasible_set',es,'.tikz')
%     xlabel('$\rho$', 'Interpreter', 'latex');
%     ylabel('d', 'Interpreter', 'latex');
%     matlab2tikz(sprintf('../Pictures/feasible_set%d.tikz',es),'relativeDataPath', '../Data', 'dataPath', '../Data', 'externalData', true,'showInfo', false,'width','\textwidth','standalone',true)

%Plot cuts
    figure(figcutoff)
    hold on
    plot([0,1],[kappa/s,kappa/s])
    ytick(es)=kappa/s;
end
ytick(es+1)=0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Compute  Cutoff Slopes when derivative of d(rho) switches sign%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

syms r
c=erfinv(r)^2;
dc=diff(erfinv(r)^2);
ddc=diff(diff(erfinv(r)^2));

derivative=(dc*c+r*c*ddc-r*dc^2)/(ddc*r^2-r*dc+c);
figure(figcutoff)
hold on
fplot(derivative,[minrho,maxrho])
xlim([minrho,maxrho])
yticks(sort(ytick))
