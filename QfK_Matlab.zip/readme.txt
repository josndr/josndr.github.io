There are 2 Scripts and 3 functions.

Scripts:
The script Optimal_Static_Choice.m simulates the optimal static choice for a given existing knowledge.
The script Evolution_Simulation.m simulates a moonshot and the subsequent catching up phase to determine the optimum.

Functions:
The function expanding.m calculates the optimal choice to expand knowledge
The function deepen.m calculates the optimal choice to deepen knowledge
The function moonshot.m calculates the behavior after a given moonshot

All three functions are needed for the Evolution script, the first two for the static choice.
The scripts generate the pictures in the main text.

The graph-generating code from the suplementary material is available upon request.

