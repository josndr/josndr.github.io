There are 3 Scripts and 2 functions.

Scripts:
The script Optimal_Static_Choice.m simulates the optimal static choice for a given existing knowledge. It illustrates Proposition 3

The script Moonshot_Payoffs_For_Different_Regimes.m calculates the payoffs of a moonshot of a given length for various cost and knowledge regimes. It illustrates Propositions 4 and 5 

The script ClosingOldCycle_or_StartingNewCycle.m calculates when a designer would use her disclosure opportunity to over the optimal moonshot. It considers the baseline ``Stuck Everywhere'' setup in which all researchers are fully symmetric and do not update. Thus once a researcher fails, all future generations fail too. As a side product it also calculates the optimal moonshot in that setting. The script illustrates Proposition 6.

Functions:
The function expanding.m calculates the optimal choice to expand knowledge
The function deepen.m calculates the optimal choice to deepen knowledge

We need the functions for the the scripts Optimal_Static_Choice.m and ClosingOldCycle_or_StartingNewCycle.m


