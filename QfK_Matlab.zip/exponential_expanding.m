function [dopt,rhoopt,Omax,awardopt,Vopt]=exponential_expanding(eta,zeta,q,s,gridd,gridrho)
% Function that determines the optimal solution when expanding the
% frontiers of research given the cost sensitivity, the award sensitivity
% and the variance cutoff

%Inputs: 
%     cost sensitivity: eta
%     award sensitivity: zeta
%     variance sensitivity: q
%     upper bound on reward likelihood: s
%     gridsize (optional): grid
%Outputs:
%    optimal distance: dopt
%    optimal precision: rhoopt
%    resulting value: Omax
%       award: awardopt
%       V: Vopt

%check if grid is provided, otherwise use default 10

if nargin<4
    error('too few parameters: please specify (eta,zeta,q,s)')
    return
elseif nargin<5
    warning('no grid values provided: using default of 10 for d and rho')
    gridd=10;
    gridrho=gridd;
elseif nargin <6
    gridrho=gridd;
    warning('no separate grid values provided: using the one provided for both d and rho')
end
    

%% EXPANDING

%% Symbolics
% syms d rho

hitbound=1;
if zeta>0
upperbound=max(6*q,s);
else
    upperbound=3*q;
end
lowerbound=10e-7;
while hitbound==1
    %% Controls
    d=linspace(lowerbound,upperbound,gridd); %ddMaximum length that can be optimal
    rho=linspace(10e-7,1,gridrho);
    d=repmat(d,length(rho),1); %d grows in columns
    rho=repmat(rho',1,length(d(1,:))); %rho grows in rows

    % Nullify potential complex values
    help1=max(d-4.*q,0);

    V=d-(d.^2- help1.^(3/2).*sqrt(d))./(6.*q);
    likelihood=(1-exp(-s*d));
    c=erfinv(rho).^2.*d;

    Obj=rho.*V+rho.*zeta.*likelihood -eta.*c;

    [~,rhoindex]=max(Obj,[],'linear');
    rhoofd=rho(rhoindex);

    [Omax,dmaxindex]=max(Obj(rhoindex));
    dopt=d(1,dmaxindex);
    rhoopt=rhoofd(dmaxindex);
    Vopt=V(rhoindex);
    Vopt=Vopt(dmaxindex);
    awardopt=likelihood(rhoindex);
    awardopt=awardopt(dmaxindex);

    if dopt<upperbound && dopt>upperbound/2
        hitbound=0;
    elseif dopt<upperbound && dopt<upperbound/2
        upperbound=upperbound/2;
    elseif dopt==s
        hitbound=0;
    else
        upperbound=1.5*upperbound;
    end
end
end