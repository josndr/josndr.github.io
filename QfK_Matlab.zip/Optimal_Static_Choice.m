%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Simulating the researachers static choice                       %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clearvars
close all
addpath(genpath('Latex_templates'))

%% Required

% package expanding.m
% package deepen.m

%% Output

% If switch below is set to 1 the following standalone tikz files will be created and
% stored in the relative path "../Pictures"

% A simulation of the optimal static choice of the researcher as a function
% of the interval length X
% It returns and graphs a vector of the optimal choices of
    % distance d
    % probability rho
    % value to society

    %The respective plot data is stored in the relative path "../Data"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%SWITCH: SET TO 1 IF YOU WANT TO STORE PICTURES AS TIKZ  %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

create_tikz=0; %set equal to 1 if you want to save results in tikz files

%% Parameters

eta=500; %cost factor
zeta=0; % irrelevant additional parameter set to $0$ for this exercise and throughout the paper
q=1; %value outside option 
gridd=500; %gridsize distance
gridrho=2500; % gridsize probability
Xmin=0; %smallest interval size
Xmax=10*q; %largest interval  size
s=1; %standardize award scheme (not relevant for this exercise. set to $1$ throughout the results of the paper

Xspace=linspace(Xmin,Xmax,gridd); %space of interavals
OX=zeros(size(Xspace));
swtch=0;
for i=1:length(Xspace) %create optimal response deepening
    X=Xspace(i);
    [d(i),rhod(i),OX(i),~,VX(i)]=deepen(eta,zeta,q,s,X,gridd,gridrho);
    if d(i)~=X/2 && swtch==0 
        swtch=1;
        firstinterior=i;
    else
    end
end
[de,rhoe,Oe]=expanding(eta,zeta,q,s,gridd,gridrho); %optimal response expanding

[~,firstdeepen]=min(abs(Oe-OX)); 
[~,largestdeepen]=max(OX);
[~,largestrho]=max(rhod);

%Cutoffs
hatX=Xspace(firstdeepen);
checkX=Xspace(largestdeepen);
tildeX=Xspace(firstinterior);
dotX=Xspace(largestrho);
maxOX=max(OX);

rhoop=rhod;
rhoop(OX<Oe)=rhoe;

rholatent=rhod;
rholatent(OX>Oe)=rhoe;
rholatent(firstdeepen)=nan;
rhoop(firstinterior)=nan;
rhoop(firstdeepen)=nan;
rhoop(1)=nan;


dop=d;
dop(OX<Oe)=de;
dlatent=d;
dlatent(OX>Oe)=de;

dop(firstinterior)=nan;
dop(firstdeepen)=nan;
dlatent(firstdeepen)=nan;
dop(1)=nan;


costd=eta.*(erfinv(rhoop)).^2.*dop.*(1-dop./Xspace);

help1=max((dop-4*q),0).^(3/2).*sqrt(dop);
help2=max((Xspace-4*q),0).^(3/2).*sqrt(Xspace);
help3=max((Xspace-dop-4*q),0).^(3/2).*sqrt(Xspace-dop);

benefitd= rhoop./(6*q).*(2.*dop.*Xspace - 2.*dop.^2 + help1-help2+help3);

Oop=OX;
Oop(Oe>OX)=Oe;
Olatent=OX;
Olatent(Oe<OX)=Oe;

figure
plot(Xspace,Olatent,'--')
hold on
plot(Xspace,Oop)
% plot(Xspace,benefitd,'--k')
% plot(Xspace,costd,'k')
xticks([hatX  dotX checkX tildeX])
yticks([0 Oe])
set(gca,'TickLabelInterpreter','latex');
xticklabels({'$\widehat{X}$', '$\dot{X}$', '$\widecheck{X}$','$\widetilde{X}$'});
yticklabels({'0','$U_R^\infty$'});
xlabel('Interval Length');
ylabel('Value to the Researcher');
ylim([0,1.1*max(benefitd)])
if create_tikz==1 %output picture if switch turned on
 matlab2tikz('../Pictures/Value_for_different_X.tikz','relativeDataPath', '../Data', 'dataPath', '../Data', 'externalData', true,'showInfo', false,'width','\textwidth','standalone',true)
end

figure
plot(Xspace,rhoop,'k')
hold on
plot(Xspace,rholatent,'--k')
xticks([hatX  dotX checkX tildeX])
yticks(rhoe)
set(gca,'TickLabelInterpreter','latex');
xticklabels({'$\widehat{X}$', '$\dot{X}$', '$\widecheck{X}$','$\widetilde{X}$'});
yticklabels({'$\rho^\infty$'});
xlabel('Interval Length')
ylabel('Probability of Finding an Answer')
ylim([0,1.1*max(rhoop)])
if create_tikz==1 %output picture if switch turned on
 matlab2tikz('../Pictures/rho_for_different_X.tikz','relativeDataPath', '../Data', 'dataPath', '../Data', 'externalData', true,'showInfo', false,'width','\textwidth','standalone',true)
end

figure
plot(Xspace,dop,'k')
hold on
plot(Xspace,dlatent,'--k')
xticks([hatX  dotX checkX tildeX])
yticks(de)
set(gca,'TickLabelInterpreter','latex');
xticklabels({'$\widehat{X}$', '$\dot{X}$', '$\widecheck{X}$','$\widetilde{X}$'});
yticklabels({'$d^\infty$'});
xlabel('Interval Length')
ylabel('Distance to Knowledge')
ylim([min(dop).*0.9,1.1*max(dop)])
if create_tikz==1 %output picture if switch turned on
     matlab2tikz('../Pictures/d_for_different_X.tikz','relativeDataPath', '../Data', 'dataPath', '../Data', 'externalData', true,'showInfo', false,'width','\textwidth','standalone',true)
end