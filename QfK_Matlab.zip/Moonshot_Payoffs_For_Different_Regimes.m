clear
close all

%% Description

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%          MOONSHOT vs 3q for different regimes                            %%
%     We compare the dynamic discounted payoffs of a moonshot              %%
%                   with the myopic optimum                                %%
%                                                                          %%
%   We compare the following regimes:                                      %%
%                                                                          %% 
%  1. A world in which researchers can select from an ocean of             %%
%  directions such that failure only initializes a change of direction but %%
%  no repeated failures                                                    %%
%                                                                          %%
%  2. A world in which there is only one direction beyond the frontier and %% 
%  if one researcher fails to obtain a discovery all subsequent researchers%%
%  fall into the same trap.                                                %%
%  Within each world we calculate two ex-ante values for a range of        %%
%  cost-parameters:                                                        %%
%   a. The ex-ante payoff ignoring any cost of doing research that the     %%
%      individual researchers have to carry                                %%
%   b. The ex-ante payoff taking these cost into account                   %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Required
% nothing
%% Output

% The values for all 4 regimes are calculated and plotted plus a comparison
% plot is generated.

%% Input

etaspace = linspace(0.01, 2, 100); % Set of cost parameters
deltaspace=linspace(0.4,0.95,50); % Set of discount factors
reference_delta=0.85; %targeted reference delta for fixed-delta plots. Code will use closest value in deltaspace.

q = 1; % error tolerance

% Size of the moonshot (Note: the code assumes that the moonshot is closed
% in one period. It may return wrong results if $X>6 q$.
X = 6 * q;

%% ||| Computations |||
%  vvv              vvv
% (DO NOT CHANGE UNLESS YOU KNOW WHAT YOU'RE DOING)

% Create parallel Pool
pool=gcp;

% Preallocate arrays
value_ocean_no_intervention = zeros(length(etaspace),length(deltaspace));
value_ocean_no_intervention_no_cost = zeros(length(etaspace),length(deltaspace));
value_fail_no_intervention = zeros(length(etaspace),length(deltaspace));
value_fail_no_intervention_no_cost = zeros(length(etaspace),length(deltaspace));
value_ocean_3q_no_cost = zeros(length(etaspace),length(deltaspace));
value_ocean_3q_w_cost = zeros(length(etaspace),length(deltaspace));
value_fail_3q_no_cost = zeros(length(etaspace),length(deltaspace));
value_fail_3q_w_cost = zeros(length(etaspace),length(deltaspace));
value_ocean_6q_no_cost = zeros(length(etaspace),length(deltaspace));
value_ocean_6q_w_cost = zeros(length(etaspace),length(deltaspace));
value_fail_6q_no_cost = zeros(length(etaspace),length(deltaspace));
value_fail_6q_w_cost = zeros(length(etaspace),length(deltaspace));

[D,E]=meshgrid(deltaspace,etaspace); %defined the grid to loop over

parfor i=1:numel(E) % loop over deltas and etas
    delta=D(i);
    eta = E(i);
    
    %% Solve researcher
    % No intervention
    op = fminsearch(@(choices) -myopic_expansion_payoff(choices, q, eta), [0, 0]);
    MV_no_intervention = op(1) * moonshot_expansion_payoff(1, q, eta, op(2));
    cost_no_intervention = eta * erfinv(op(1))^2 * op(2);
    % Closing a moonshot
    rhoclosure = fminsearch(@(choice) -moonshot_closure(choice, q, eta, X), 0);
    cost_closure = eta * erfinv(rhoclosure)^2 * X / 4; % Cost of closing
    
    %% Determine benefits and cost of various regimes

    % Ocean 
    % No intervention
    benefit_ocean_inf_horizon_no_intervention = MV_no_intervention / (1 - delta)^2;
    cost_inf_horizon_no_intervention = cost_no_intervention / (1 - delta);

    % Myopic Optimum
    benefit_ocean_3q = moonshot_expansion_payoff(1, q, eta, 3 * q) / (1 - delta) + ...
        delta * benefit_ocean_inf_horizon_no_intervention;
    cost_3q = delta * cost_inf_horizon_no_intervention;

    benefit_ocean_6q = moonshot_expansion_payoff(1, q, eta, X) / (1 - delta) + ...
        delta / (1 - delta) * rhoclosure * moonshot_closure(1, q, eta, X) + ...
        delta^2 * benefit_ocean_inf_horizon_no_intervention;
    cost_ocean_6q = delta * cost_closure + delta^2 * cost_inf_horizon_no_intervention;

    % Repeated Failure
    % No intervention
    benefit_fail_inf_horizon_no_intervention = MV_no_intervention / (1 - op(1) * delta)^2;

    % Myopic optimum
    benefit_fail_3q = moonshot_expansion_payoff(1, q, eta, 3 * q) / (1 - delta) + ...
        delta * benefit_fail_inf_horizon_no_intervention;

    % Moonshot
    benefit_fail_6q = moonshot_expansion_payoff(1, q, eta, X) / (1 - delta) + ...
        delta / (1 - delta) * rhoclosure * moonshot_closure(1, q, eta, X) + ...
        delta^2 * rhoclosure * benefit_fail_inf_horizon_no_intervention;
    cost_fail_6q = delta * cost_closure + ...
        delta^2 * (rhoclosure * cost_inf_horizon_no_intervention + (1 - rhoclosure) * cost_closure / (1 - delta));
    
    %% Determine ex-ante values

    % No Intervention
    value_ocean_no_intervention(i) = benefit_ocean_inf_horizon_no_intervention - cost_inf_horizon_no_intervention;
    value_ocean_no_intervention_no_cost(i) = benefit_ocean_inf_horizon_no_intervention;
    value_fail_no_intervention(i) = benefit_fail_inf_horizon_no_intervention - cost_inf_horizon_no_intervention;
    value_fail_no_intervention_no_cost(i) = benefit_fail_inf_horizon_no_intervention;

    % Myopic optimum
    value_ocean_3q_no_cost(i) = benefit_ocean_3q;
    value_ocean_3q_w_cost(i) = benefit_ocean_3q - cost_3q;
    value_fail_3q_no_cost(i) = benefit_fail_3q;
    value_fail_3q_w_cost(i) = benefit_fail_3q - cost_3q;

    % Moonshot    
    value_ocean_6q_no_cost(i) = benefit_ocean_6q;
    value_ocean_6q_w_cost(i) = benefit_ocean_6q - cost_ocean_6q;
    value_fail_6q_no_cost(i) = benefit_fail_6q;
    value_fail_6q_w_cost(i) = benefit_fail_6q - cost_fail_6q;

    
end
%% Clean Workspace
    clearvars -except etaspace deltaspace q i X reference_delta value*


%% Generating Graphs (delta fixed)

index=find(min(abs(deltaspace-reference_delta))==abs(deltaspace-reference_delta));

display(['Provided Reference Delta may not be hit. Code uses closest susbstitute at: ' num2str(deltaspace(index))])


fig1=figure %Plot myopic vs Moonshot
% 
% Subplot 1
subplot(2, 2, 1)
hold on
plot(etaspace, value_ocean_3q_w_cost(:,index), 'b', 'DisplayName', 'Myopic Optimum')
plot(etaspace, value_ocean_6q_w_cost(:,index), 'r', 'DisplayName', ['Moonshot at ', num2str(X/q), 'q'])
% xlabel('$\eta$','interpreter','latex')
ylabel('Value to Designer')
title('Ocean w/ Cost')

% Subplot 2
subplot(2, 2, 2)
hold on
plot(etaspace, value_ocean_3q_no_cost(:,index), 'b', 'DisplayName', 'Myopic Optimum')
plot(etaspace, value_ocean_6q_no_cost(:,index), 'r','DisplayName', ['Moonshot at ', num2str(X/q), 'q'])
% xlabel('$\eta$','interpreter','latex')
% ylabel('Value to Designer')
title('Ocean no Cost')

% Subplot 3
subplot(2, 2, 3)
hold on
plot(etaspace, value_fail_3q_w_cost(:,index), 'b', 'DisplayName', 'Myopic Optimum')
plot(etaspace, value_fail_6q_w_cost(:,index), 'r','DisplayName', ['Moonshot at ', num2str(X/q), 'q'])
xlabel('$\eta$','interpreter','latex')
ylabel('Value to Designer')
title('Failure w/ Cost')

% Subplot 4
subplot(2, 2, 4)
hold on
plot(etaspace, value_fail_3q_no_cost(:,index), 'b', 'DisplayName', 'Myopic Optimum')
plot(etaspace, value_fail_6q_no_cost(:,index), 'r','DisplayName', ['Moonshot at ', num2str(X/q), 'q'])
xlabel('$\eta$','interpreter','latex')
% ylabel('Value to Designer')
title('Failure no Cost')


% Adjust Position for Subplots
subplot(2, 2, 1)
pos = get(gca, 'Position');
pos(2) = pos(2) - 0.03; % Adjusted vertical position
set(gca, 'Position', pos);

subplot(2, 2, 2)
pos = get(gca, 'Position');
pos(2) = pos(2) - 0.03; % Adjusted vertical position
set(gca, 'Position', pos);

% Add Legend
legend('Location', 'Best')
% Adjust Position for Super Title
axes('Position', [0, 0.95, 1, 0.03]); % Adjusted vertical position
set(gca, 'Color', 'None', 'XColor', 'None', 'YColor', 'None');
text(0.5, 0, ['Comparison Moonshot to 3q for \delta=', num2str(round(deltaspace(index),2))], 'FontSize', 11, 'FontWeight', 'Bold', ...
    'HorizontalAlignment', 'Center', 'VerticalAlignment', 'Bottom');

print(fig1,'AllComparison','-dpng')

fig2=figure % Plot relative value of moonshot for all regimes
plot(etaspace, value_ocean_6q_w_cost(:,index) - value_ocean_3q_w_cost(:,index), 'k','DisplayName', 'Ocean w/ cost')
hold on
plot(etaspace, value_ocean_6q_no_cost(:,index) - value_ocean_3q_no_cost(:,index), '--k','DisplayName', 'Ocean w/o cost')
plot(etaspace, value_fail_6q_no_cost(:,index) - value_fail_3q_no_cost(:,index), '.k','DisplayName', 'Failure w/o cost')
plot(etaspace, value_fail_6q_w_cost(:,index) - value_fail_3q_w_cost(:,index), '.-k','DisplayName', 'Failure w/ cost')
title(['Relative benefit of moonshot(', num2str(X/q), 'q)  over 3q with \delta=', num2str(round(deltaspace(index),2))])
xlabel('$\eta$','interpreter','latex')
ylabel('Gain for the Designer')
legend('Location', 'Best')

print(fig2,'All_In_One_Relative','-dpng')

%% Generation Graphs (heatmaps for all parameters combos)

% Define the scale factor
scale_factor = 1.7;

% Get the default figure position and size
default_position = get(0, 'DefaultFigurePosition');
scaled_size = default_position(3:4) * scale_factor;

% Calculate a new bottom position to lower the figure on the screen
new_bottom = default_position(2) - (scaled_size(2) - default_position(4));

% Create the figure with adjusted position
fig3 = figure('Position', [default_position(1) new_bottom scaled_size]);

% Apply the custom colormap
colormap autumn

% Create tiled layout with adjusted padding
t = tiledlayout(fig3, 2, 2, 'TileSpacing', 'Compact', 'Padding', 'loose');

% Tile 1
nexttile
contourf(etaspace, deltaspace, (value_ocean_6q_w_cost - value_ocean_3q_w_cost)');
ylabel('$\delta$', 'interpreter', 'latex');
title('Ocean w/ Cost');

% Set color limits to ensure the transition at 0
clim([-0.2, 0.2]);

% Tile 2
nexttile
contourf(etaspace, deltaspace, (value_ocean_6q_no_cost - value_ocean_3q_no_cost)');
title('Ocean no Cost');

% Set color limits to ensure the transition at 0
clim([-0.2, 0.2]);

% Tile 3
nexttile
contourf(etaspace, deltaspace, (value_fail_6q_w_cost - value_fail_3q_w_cost)');
xlabel('$\eta$', 'interpreter', 'latex');
ylabel('$\delta$', 'interpreter', 'latex');
title('Failure w/ Cost');

% Set color limits to ensure the transition at 0
clim([-0.2, 0.2]);

% Tile 4
nexttile
contourf(etaspace, deltaspace, (value_fail_6q_no_cost - value_fail_3q_no_cost)');
xlabel('$\eta$', 'interpreter', 'latex');
title('Failure no Cost');

% Set color limits to ensure the transition at 0
clim([-0.2, 0.2]);

% Add a super title positioned slightly above
annotation('textbox', [0, 0.96, 1, 0.05], 'String', 'Comparison Moonshot to 3q', ...
    'FontSize', 11, 'FontWeight', 'Bold', 'HorizontalAlignment', 'Center', ...
    'VerticalAlignment', 'Bottom', 'EdgeColor', 'none', 'Color', 'k');


% Add colored boxes and text annotations for pseudo-legend horizontally
legend_y = 0.02; % Adjust this to position the legend appropriately
legend_text_y = legend_y + 0.01; % Adjusted for text alignment
box_width = 0.02;
box_height = 0.03;
text_width = 0.15;
text_height = 0.03;
space_between = 0.01;

% Red Box
annotation('rectangle', [0.2, legend_y, box_width, box_height], 'FaceColor', 'r', 'EdgeColor', 'none');
% Red Text
annotation('textbox', [0.22, legend_text_y, text_width, text_height], 'String', 'MS not preferred', ...
    'FitBoxToText', 'on', 'EdgeColor', 'none', 'Color', 'k', 'FontSize', 10);

% Orange Box
annotation('rectangle', [0.45, legend_y, box_width, box_height], 'FaceColor', [1 0.5 0], 'EdgeColor', 'none');
% Orange Text
annotation('textbox', [0.47, legend_text_y, text_width, text_height], 'String', 'MS slightly preferred', ...
    'FitBoxToText', 'on', 'EdgeColor', 'none', 'Color', 'k', 'FontSize', 10);

% Yellow Box
annotation('rectangle', [0.7, legend_y, box_width, box_height], 'FaceColor', 'y', 'EdgeColor', 'none');
% Yellow Text
annotation('textbox', [0.72, legend_text_y, text_width, text_height], 'String', 'MS strongly preferred', ...
    'FitBoxToText', 'on', 'EdgeColor', 'none', 'Color', 'k', 'FontSize', 10);

print(fig3,'Heatmap','-dpng')


%% Functions to run code


% R-Utility optimal myopic expansion
function utility=myopic_expansion_payoff(choices,q,eta)
    d=choices(2);
    rho=choices(1);
    benefit= (d-d^2./(6*q));
    cost=eta*erfinv(rho)^2.*d;
    utility=rho.*benefit-cost;
end


% R-Utility expanding to anything
% --- by setting the first argument to 1 we obtain the benefits of 
%     the moonshot without the respective cost.
function utility=moonshot_expansion_payoff(rho,q,eta,moonshot)
    benefit = (moonshot - moonshot.^2 / (6 * q)) + ...
        (moonshot > 4*q) .* (sqrt(moonshot) .* (moonshot - 4 * q)^(3/2)) / (6 * q); %added if d>4q
    if rho==1
        cost=0;%setting cost=0 if rho=1 is set exogenous
    else
        cost=(eta .* erfinv(rho).^2 .* moonshot); 
    end
    utility=rho.*benefit-cost;
end


% R-utilty closing moonshot 
% --- by setting the first argument to 1 we obtain the benefits of 
%     the moonshot without the respective cost.
function valueadded=moonshot_closure(rho,q,eta,moonshot)
    benefit= 2*(moonshot/2 - (moonshot/2)^2./(6*q))-moonshot_expansion_payoff(1,q,eta,moonshot);

        if rho==1
            cost=0;%setting cost=0 if rho=1 is set exogenous
        else
            cost=eta*erfinv(rho)^2*moonshot/4; %setting cost=0 if rho=1 is set exogenous
        end

    valueadded=rho.*benefit-cost;
end