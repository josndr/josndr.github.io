
cd(fileparts(which(mfilename)))
clearvars
close all
addpath(genpath('../Latex_templates'))

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Simulating paths of knowledge evolution. %%
%  And there consequences for the outcome   %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Required

% package expanding.m
% package deepen.m
% package moonshot.m

%% Output

% If switch below is set to 1 the following standalone tikz files will be created and
% stored in the relative path "../Pictures"

% A simulation of the landscape given the moonshot
% Payoff of moonshots over step-by-step research in terms of
%       discount factor DELTA
%       cost parameter ETA

%The respective plot data is stored in the relative path "../Data"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%SWITCH: SET TO 1 IF YOU WANT TO STORE PICTURES AS TIKZ  %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

create_tikz=0; %set equal to 1 if you want to save results in tikz files

%% Parameters
%parameters
rounds=7; % time horizon for pictures
eta=1; %baseline cost factor
etamin=0.001; %minimun for eta simulations
etamax=3; %maximum for eta simulations
grideta=300;
gridd=500; %gridsize
gridrho=2500;
deltalength=50; %number of points discount factor
q=1; %value outside option
delta=0.9; %baseline discount factor
lowestMoonshot=expanding(eta,0,q,1,gridd,gridrho);%3*q;
highestMoonshot=12*q;
noMoonshots=500; %number of moonshots simulated
noIndcurves=5; %how many indifference curves to display

%% Computations (DO NOT CHANGE UNLESS YOU KNOW WHAT YOU'RE DOING)

scndround=3*q+expanding(eta,0,q,1,gridd,gridrho); %ensure that you get 3q first round 3q+d^infty second
moonshots=linspace(lowestMoonshot,highestMoonshot,noMoonshots);

set(0,'DefaultFigureVisible','off') %turn figure output off: Recommended if vector Moonshots>5

rhos=figure('visible','off');
Vs=figure('visible','off');

overallvalue=zeros(size(moonshots));
values=zeros(length(moonshots),rounds);
probabilities=zeros(length(moonshots),rounds);

for m=1:length(moonshots)
    mshot=moonshots(m);
    [overallvalue(m),values(m,:),probabilities(m,:),scatt(m),rhos,Vs,X(m,:),rhoprod(m,:),d(m,:),rho(m,:),deep(m,:)]=moonshot(eta,q,mshot,delta,rounds,gridd,gridrho,rhos,Vs,create_tikz);
end
set(0,'DefaultFigureVisible','on') %turn figure output back on
moonshotsize=figure;

overallvalue(diff(overallvalue)>0.01)=nan;
overallvalue(isnan(diff(overallvalue)))=nan;
plot(moonshots,overallvalue);
if create_tikz==1 %output picture if switch turned on
    matlab2tikz(sprintf('../Pictures/moonshot%d.tikz',round(10*eta,0)),'relativeDataPath', '../Data', 'dataPath', '../Data', 'externalData', true,'showInfo', false,'width','\textwidth','standalone',true)
end


etas=linspace(etamin,etamax,grideta);
for e=1:length(etas)
    e_eta=etas(e);
    ms6q=moonshot(e_eta,q,6*q,delta,5,gridd,gridrho);
    ms3q=moonshot(e_eta,q,3*q,delta,5,gridd,gridrho);
    e_gain6q(e)=ms6q-ms3q;
end
moonshotvalueeta=figure;
plot(etas,e_gain6q)

if create_tikz==1 %output picture if switch turned on
     matlab2tikz('../Pictures/moonshotbyeta.tikz','relativeDataPath', '../Data', 'dataPath', '../Data', 'externalData', true,'showInfo', false,'width','\textwidth','standalone',true)
end

deltaspace=linspace(0,0.99,deltalength);
for de=1:length(deltaspace)
    del=deltaspace(de);
    del6q=moonshot(eta,q,6*q,del,5,gridd,gridrho);
    del3q=moonshot(eta,q,3*q,del,5,gridd,gridrho);
    del_gain6q(de)=del6q-del3q;
end

moonshotvalued=figure;
plot(deltaspace,del_gain6q)
if create_tikz==1 %output picture if switch turned on
    matlab2tikz('../Pictures/moonshotbydelta.tikz','relativeDataPath', '../Data', 'dataPath', '../Data', 'externalData', true,'showInfo', false,'width','\textwidth','standalone',true)
end

%% indifferencecurves rho,d moonshots
% Here we plot indifference curves in the rho,d space for the baseline
% discount factor simulating the moonshot outcome.
% The smallest indiffernce curve corresponds to the utility the long-lived
% decision maker gets if she implements the myopically optimal outcome with
% probability 0.468, the largest if she implements it with probability 0.638. 

indcurvevalues=linspace(0.451*overallvalue(1),0.621*overallvalue(1),noIndcurves); %
for j=1:length(indcurvevalues)
rhoind(j,:)=indcurvevalues(j)./overallvalue;
end
figure
plot(moonshots,rhoind)
mrhoind=rhoind;
save('moonshotws','moonshots','mrhoind')

