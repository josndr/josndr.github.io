
%Simulating moonshots

Evolution Simulation.m 

% Deriving optimal Funding

optimal_funding.m

%% Packages to calculate outcomes

expanding.m %calculates optimal expanding research given parameters

deepen.m %calculates optimal deepening research given parameters

moonshot.m % calculates moonshots given parameters.
