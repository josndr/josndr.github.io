cd(fileparts(which(mfilename)))
clearvars
close all
addpath(genpath('src')) %Load Matlab2tikz


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plotting Optimal Funding            %
% If the Funder maximizes $\rho*V$    %
% For different relative cost $kappa% %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Required
%package expanding.m
% matlab2tikz (if you want to save pictures in tikz)


%% Output

% If switch below is set to 1 the following standalone tikz files will be created and
% stored in the relative path "../Pictures"

%for each cost parameter "kappa"
% optimal_fundingkappa.tikz

%The respective plot data is stored in the relative path "../Data"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%SWITCHES: SET FIRST TO 1 IF YOU WANT TO STORE PICTURES AS TIKZ             %
%%%%%%%%%%%%%SET SECOND TO 1 IF YOU WANT TO CALCULATE IND CURVES ENDOGENOUSLY %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

create_tikz=0; %set equal to 1 if you want to save results in tikz files

endogenous_indiffcurves=0; %SWITCH (see below)

% set switch above to 1 if you want to compute the indifference curves endogenously. 
% If it is turned on indifference curves are depicted that lie between those
%created by the polar probabilities
% NB: The optimal level may not be included

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% RECOMMENDATION: run with endogenous curves first to determine the ball  %
% park (variable indcurvespace) and then fine tune by hand using          %
% exogenous indcurves to produce meaningful pictures.                     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Input
%%%%%%%%%%%%%%
% Parameters %
%%%%%%%%%%%%%%

% Model Parameters
Kmin=3; %min budget
Kmax=3; %max budget
NoBudgets=1; %No of budgets calculated
s=6; % Prize guarantee level
etabase=1; %Initial cost factor eta
zetabase=0; %Initial reward zeta
q=1; %value of outside option
kappaspace=[7 14]; %relative prices to funder of providing cost reduction (v rewards)
Kspace=linspace(Kmin,Kmax,NoBudgets); %laying out the space of budgets

clear NoBudgets Kmax Kmin %Clear to avoid clutter

%Computing Precision
gridd=500; %distance grid
gridrho=800; %probability grid
budgetgrid=300;

% No Indifference curves to draw
noI=5; %No of curves to draw

%ONLY RELEVANT WHEN IND CURVES EXOGENOUS
% Indcurve bounds (insert only bounds)
lowest_ex_indcurve=0.64;
highest_ex_indcurve=0.755;

%Calculate indcurvespace if exogenously determined
if endogenous_indiffcurves~=1 %if switch is not turned on create exogenous indiff curves
    indcurvespace=linspace(lowest_ex_indcurve,highest_ex_indcurve,noI); 
    clear lowest highest noI %avoid clutter
end



%%%%%%%%%%%%%%%%%%%%%%%
% uncomment if needed %
%%%%%%%%%%%%%%%%%%%%%%%

%give full vector 

% indcurvespace=[0.55 0.6 0.65 0.7012 0.725];


%% Computations (DO NOT CHANGE UNLESS YOU KNOW WHAT YOU'RE DOING)



%Check if assumptions are met
if s<min(0.1,3*q)
    warning('s is too low to provide meaningful result')
end

%Check if Budget works
if max(Kspace)/min(kappaspace)>etabase
    error('budget too large. Removes all frictions. Results have no meaning. Please reduce maximum budget to satisfy Kmax<etabase/min(kappaspace)')
end


% cost functions and their derivatives
c= @(rho) erfinv(rho).^2; %cost of rho
diffc=@(rho) pi.^(1/2).*exp(erfinv(rho).^2).*erfinv(rho); %derivative of c
d2c=@(rho) (pi.*exp(2*erfinv(rho).^2))/2 + pi.*exp(2*erfinv(rho).^2).*erfinv(rho).^2; % second derivative of c;


for kappa=kappaspace

%%%%%%%%%%%%%%%%%%%%%
% feasible Set      %
%%%%%%%%%%%%%%%%%%%%%

    figure
    hold on
    

    for i=1:length(Kspace)
        clear dcorner rhocorner d rho
        K=Kspace(i);
    % Determine bounds
        MRS= @(rho) (2*diffc(rho) - c(rho)/rho)*s;
        options = optimset('Display','off');
        boundrho=fsolve(@(rho) MRS(rho)-kappa,.9,options);

       [d1,rho1]=expanding(etabase,zetabase+K,q,s,gridd,gridrho);
       scatter(rho1,d1,'o')
       [d2,rho2]=expanding(etabase-K/kappa,zetabase,q,s,gridd,gridrho);
       scatter(rho2,d2,'s')

       maxrho=max(rho1,rho2); %candidate for maxrho
       minrho=min(rho1,rho2); %candidate for minrho
         
       if K+s~=kappa*etabase %regular case
                x=linspace(0,K,budgetgrid);          
            if d1==s
                dcorner=d1;
                rhocorner=rho1;
                i=1;
                while dcorner(i)==s
                    i=i+1;
                    [dcorner(i),rhocorner(i)]=expanding(etabase-x(i)/kappa,zetabase+(K-x(i)),q,s,gridd,gridrho);
                end
                plot(rhocorner(1:end-1),dcorner(1:end-1))                
            else
                i=1;
                dcorner=0;
                rhocorner=nan;
            end
            zetanoextreme=K-x(i);
            etanoextreme=etabase-x(i)/kappa;
            [~,rhonoextreme]=expanding(etanoextreme,zetanoextreme,q,s,gridd,gridrho);
            rho=linspace(rhonoextreme,rho2,100);
            d=6.*q.*(K+s-kappa.*etabase).*(rho.*diffc(rho)-c(rho))./(2*s.*rho.*diffc(rho)-s.*c(rho)-kappa.*rho);
            plot(rho,d)
           
%             
        else %special case that budget line=isorho curve.
            rho=boundrho;
            dmax=expanding(etabase-K/kappa,0,q,s,gridd,gridrho);
            dmin=expanding(etabase,K,q,s,gridd,gridrho);
            line([rho,rho],[dmin,dmax])
       end
       

    end

    clear polarmax polarmin boundrho %avoid clutter

    
    %%%%%%%%%%%%%%%%%%%%%%%
    % Indifference curves %
    %%%%%%%%%%%%%%%%%%%%%%%

    
    %compute endogenous indifference curves to display if switch is turned
    %on in premble
    if endogenous_indiffcurves==1
        [rholow,I]=min(rho);
        dlow=d(I);
        if rholow<rho1
        else
            rholow=rho1;
            dlow=d1;
        end

        [rhohigh,I] =max(rho);
        dhigh=d(I);
        if rhohigh>rho1
        else
            rhohigh=rho1;
            dhigh=d1;
        end
        
        
        help=max((dlow-4.*q),0);
        lowest=rholow.*(1/(6.*q)).*(6.*q.*dlow-dlow.^2+sqrt(dlow).*help^(3/2));
        help=max((dhigh-4.*q),0);
        highest=rhohigh*(1/(6.*q)).*(6.*q.*dhigh-dhigh.^2+sqrt(dhigh).*help.^(3/2));
        indcurvespace=linspace(lowest,highest,noI);
        clear help lowest highest rholow rhohigh dlow dhigh rho1 rho2 
    end
    
    if dcorner(1)==0
        dspace=linspace(0.0001,max(d)+q,100);
    else
        dspace=linspace(0.0001,s,100);
    end
        help=max((dspace-4.*q),0);
    V=(1/(6.*q)).*(6.*q.*dspace-dspace.^2+sqrt(dspace).*help.^(3/2));
     %avoid clutter
    rhoind=nan(length(indcurvespace),length(dspace));
    for i=1:length(indcurvespace)
        rhoh= indcurvespace(i)./V;
        rhoh(rhoh>1)=nan;
        rhoh(rhoh<0)=nan;
        rhoind(i,:)=rhoh;
        plot(rhoind(i,:),dspace)
    end
    clear help rhoh V dspace %avoid clutter
    
    % Axis and label options.
    xlabel('$\rho$', 'Interpreter', 'latex');
    ylabel('d', 'Interpreter', 'latex');
    set(gca,'TickLabelInterpreter','latex');
    tickvektor=[0.25,0.5,0.75,1];
    ticklabelvektor=["0.25","0.5","0.75","1"];
    if length(Kspace)==1 %Provide mins and max rhos (only if Kspace is a singleton)
        tickvektor(end+1)=min(rho);
        ticklabelvektor(end+1)=["$\rho'$"];
%         if min(rhocorner)>=min(rho)
%             ticklabelvektor(end)=["$\underline{\rho}=\rho'$"];
%         else
%            tickvektor(end+1)=min(rhocorner); 
%             ticklabelvektor(end+1)=["$\underline{\rho}$"];
%         end
        tickvektor(end+1)=max(rho);
        ticklabelvektor(end+1)=["$\rho''$"];
%         if max(rhocorner)<=max(rho)
%             ticklabelvektor(end)=["$\overline{\rho}=\rho''$"];
%         else
%            tickvektor(end+1)=max(rhocorner); 
%            ticklabelvektor(end+1)=["$\overline{\rho}$"];
%         end        
    end
    [tickvektor,order]=sort(tickvektor);
    ticklabelvektor=ticklabelvektor(order);
    xticks(tickvektor)
    xticklabels(ticklabelvektor)
    if create_tikz==1 %output picture if switch turned on
        matlab2tikz(sprintf('../Pictures/optimal_funding%d.tikz',kappa),'relativeDataPath', '../Data', 'dataPath', '../Data', 'externalData', true,'showInfo', false,'width','\textwidth','standalone',true)
    end

end
clear noI i order tickvektor