# Figure Workflow

This workflow separates numerical/data generation from plotting. The old mixed
Mathematica code remains available, but the new plotting files should read from
generated WXF caches instead of recomputing model objects inside every plot.

## Backend

By default, the workflow does **not** evaluate
`PartialNonCommitmentCleaner.nb` directly. It also does not modify that
notebook. However, it assumes this has run at least once to produce the selector functions mentioned below.

By default, `GenerateFigureData.wl` loads the saved selector cache. It first
tries:

- `Code/partial_nc_selector_cache.mx`

and falls back to:

- `Code/partial_nc_selector_cache.wl`

This cache was produced from the previous no-commitment code and contains the
selector functions needed by the new generator, including the no-commitment
policy/classification functions and the commitment policy function.

Only if you set:

```wl
"RefreshSelectorDefinitions" -> True
```

in `GenerateFigureData.wl`, the workflow tries to rerun:

- `Code/PartialNonCommitmentCleaner.nb`

It evaluates that notebook with `NotebookEvaluate[..., InsertResults -> False]`.
That refresh mode is optional, requires a Wolfram installation that can evaluate
notebooks, and should be used only when the selector cache is stale.

## What Output We Produce

The workflow produces three families of figure outputs:

- **No-commitment plots**
  - strategy curves as a function of `theta`
  - strategy curves as a function of `b`
  - sampled regime panels attached to those curve plots

- **Commitment plots**
  - commitment-only strategy curves as a function of `theta`
  - commitment-only strategy curves as a function of `b`
  - sampled commitment regime panels

- **Region plots**
  - no-commitment region plot in the `(theta, b)` plane
  - commitment region plot in the `(theta, b)` plane
  - no-commitment overlay for cases where the principal's on-path constraint binds

Each plotting workflow exports:

- `.pdf` publication-style graphics
- `.wxf` Mathematica graphics objects

The region PDFs are rasterized at high resolution to avoid enormous vector PDFs
from the dense hatching/region grid. The editable Mathematica versions are
still stored as WXF.

## Files Needed As Backend

Core workflow files:

- `Code/FigureDataWorkflow.wl`
  - shared helper package for loading selectors, generating data, plotting, and exporting

- `Code/GenerateFigureData.wl`
  - main data-generation driver
  - contains the default parameters and grid sizes

- `Code/GenerateFigureData.nb`
  - thin Mathematica notebook launcher for `GenerateFigureData.wl`

Selector/model backend:

- `Code/partial_nc_selector_cache.mx`
  - default selector cache used by the generator

- `Code/partial_nc_selector_cache.wl`
  - text fallback if the MX cache is unavailable

Optional data generation source:

- `Code/PartialNonCommitmentCleaner.nb`
  - only used if `"RefreshSelectorDefinitions" -> True`
  - otherwise untouched

Plotting drivers:

- `Code/NoCommitmentPlots.wl`
- `Code/CommitmentPlots.wl`
- `Code/RegionPlots.wl`

Cache snapshot helpers:

- `Code/SaveGeneratedDataSnapshot.wl`
  - saves the current `Code/plot_cache/` WXF files into a parameter-named folder
    under `generated_data/`

- `Code/RestoreGeneratedDataSnapshot.wl`
  - restores a saved snapshot back into `Code/plot_cache/` so the plotting
    scripts can use it

Thin notebook launchers:

- `Code/NoCommitmentPlots.nb`
- `Code/CommitmentPlots.nb`
- `Code/RegionPlots.nb`

## What Data Is Generated

Running `GenerateFigureData.nb` or `GenerateFigureData.wl` creates value-level
WXF caches in:

```text
Code/plot_cache/
```

Main generated data files:

- `figure_data_bundle.wxf`
  - all generated data in one association

- `Metadata.wxf`
  - parameters, grid sizes, generation time, and workflow version

- `NoCommitmentThetaCurves.wxf`
- `NoCommitmentBCurves.wxf`
- `NoCommitmentThetaRegime.wxf`
- `NoCommitmentBRegime.wxf`

- `CommitmentThetaCurves.wxf`
- `CommitmentBCurves.wxf`
- `CommitmentThetaRegime.wxf`
- `CommitmentBRegime.wxf`

- `NoCommitmentRegionThetaB.wxf`
  - theta grid, b grid, no-commitment class grid, policy grid, and binding-constraint overlay grid

- `CommitmentRegionThetaB.wxf`
  - theta grid, b grid, and commitment class grid

## Where Figure Output Is Stored

The plotting scripts write figure outputs to:

```text
Graphs/generated/
```

Expected output files include:

- `no_commitment_theta_panel.pdf`
- `no_commitment_theta_panel.wxf`
- `no_commitment_theta_curves.pdf`
- `no_commitment_theta_curves.wxf`

- `no_commitment_b_panel.pdf`
- `no_commitment_b_panel.wxf`
- `no_commitment_b_curves.pdf`
- `no_commitment_b_curves.wxf`

- `commitment_theta_panel.pdf`
- `commitment_theta_panel.wxf`
- `commitment_theta_curves.pdf`
- `commitment_theta_curves.wxf`

- `commitment_b_panel.pdf`
- `commitment_b_panel.wxf`
- `commitment_b_curves.pdf`
- `commitment_b_curves.wxf`

- `regions_theta_b.pdf`
- `regions_theta_b.wxf`

- `commitment_regions_theta_b.pdf`
- `commitment_regions_theta_b.wxf`

## Requirements

- Wolfram Mathematica or Wolfram Engine with `wolframscript` available on
  `PATH` for the command-line `.wl` scripts.
- Mathematica Desktop, or another Wolfram setup that can evaluate notebooks, for
  the `.nb` launchers and for `"RefreshSelectorDefinitions" -> True`.
- The saved selector caches in `Code/partial_nc_selector_cache.mx` and
  `Code/partial_nc_selector_cache.wl`. These are already in the repository, so
  the normal workflow does not need to rerun
  `Code/PartialNonCommitmentCleaner.nb`.

## How To Run

Preferred Mathematica front-end workflow:

1. Open `Code/GenerateFigureData.nb`.
2. Evaluate its input cell.
3. Open and evaluate any plotting notebook:
   - `Code/NoCommitmentPlots.nb`
   - `Code/CommitmentPlots.nb`
   - `Code/RegionPlots.nb`

Command-line workflow, once `wolframscript` is activated:

```powershell
wolframscript -file Code/GenerateFigureData.wl
wolframscript -file Code/SaveGeneratedDataSnapshot.wl
wolframscript -file Code/NoCommitmentPlots.wl
wolframscript -file Code/CommitmentPlots.wl
wolframscript -file Code/RegionPlots.wl
```

## Saving And Reusing Generated Data

After running `GenerateFigureData.wl`, save the generated cache with:

```powershell
wolframscript -file Code/SaveGeneratedDataSnapshot.wl
```

This copies the current `Code/plot_cache/*.wxf` files into:

```text
generated_data/<parameter-and-grid-description>/
```

The folder name encodes `m`, `beta`, `b`, `theta`, curve grid size, region grid
size, and the plotted ranges. If the same snapshot folder already exists, the
script stops instead of overwriting it. To overwrite, set:

```wl
overwriteExisting = True
```

near the top of `Code/SaveGeneratedDataSnapshot.wl`.

To reuse existing generated data later, restore a snapshot into `Code/plot_cache`
with:

```powershell
wolframscript -file Code/RestoreGeneratedDataSnapshot.wl <snapshot-folder-name>
```

Then run the plotting scripts normally:

```powershell
wolframscript -file Code/NoCommitmentPlots.wl
wolframscript -file Code/CommitmentPlots.wl
wolframscript -file Code/RegionPlots.wl
```

If you run the restore script without a folder name, it prints the available
snapshots under `generated_data/`.

## Where To Input Parameters

Economic/model parameters are entered in:

```text
Code/GenerateFigureData.wl
```

Look for the block:

```wl
(* USER INPUT: ECONOMIC PARAMETERS AND GRIDS *)
```

The main line is:

```wl
"Params" -> <|"m" -> .25, "beta" -> .5, "b" -> .55, "theta" -> .19|>
```

Important: after changing `m`, `beta`, `b`, `theta`, or grid ranges, rerun
`GenerateFigureData.nb` or `GenerateFigureData.wl`. The plotting files only
read the generated cache; they do not recompute the economics.

Also rerun `GenerateFigureData.nb` or `GenerateFigureData.wl` after workflow
updates that add new generated data keys, such as `CommitmentRegionThetaB`.

Grid/domain controls are in the same block:

```wl
"ThetaRange" -> {0., .5 - 10^-5}
"BRange" -> {0., 2}
"RegionBRange" -> {10^-5, 2}
"CurveGridSize" -> 301
"RegionGridSize" -> 350
"ReuseRegionCache" -> True
```

`RegionGridSize` is the expensive one because it evaluates the selector on a
two-dimensional grid.

With `"ReuseRegionCache" -> True`, `GenerateFigureData.wl` reuses existing
region grids when only the baseline slice parameters `b` and/or `theta` change.
It validates reuse against `m`, `beta`, `ThetaRange`, `RegionBRange`, and
`RegionGridSize`. If those region-defining inputs changed, or if the required
region cache files are missing, it recomputes the regions. When reuse happens,
the generator prints a `WARNING: Reusing ... region grid cache` line so it is
clear that only the curve slices are being resampled.

## Where To Input Formatting Choices

Shared colors, hatching, line styles, and labels are entered in one central
file:

```text
Code/FigureStyleConfig.wl
```

Changing this file changes the style used by commitment plots, no-commitment
plots, and region plots.

Region colors and hatching are controlled by:

```wl
"RegionClassOrder" -> {4, 1, 2, 3, 0}
"CommitmentRegionClassOrder" -> {4, 1, 2, 3}

"RegionClassColors" -> <|
  4 -> RGBColor[1., 191/255, 0.],
  1 -> RGBColor[227/255, 85/255, 10/255],
  2 -> White,
  3 -> RGBColor[0., 158/255, 115/255],
  0 -> Black,
  -9 -> White
|>

"RegionHatches" -> <|
  1 -> "NorthEast",
  3 -> "Vertical"
|>

"RegionHatchLineColors" -> <|
  1 -> White,
  3 -> White
|>

"RegionHatchDataSpacing" -> .035
"RegionHatchSampleCount" -> 650
```

Class codes are:

- `-9`: no match
- `0`: NES
- `1`: full embracing
- `2`: partial embracing
- `3`: opportunism
- `4`: first best

Default region design:

- first best: Amber `#FFBF00`, solid fill
- full embracing: white fill with Vermilion `RGB(227,85,10)` north-east hatching
- partial embracing: white
- opportunism: white fill with BluishGreen `RGB(0,158,115)` vertical hatching
- NES: black, solid fill
- no match: white and omitted from the legend

The commitment region plot uses `CommitmentRegionClassOrder`, so it omits the
NES legend entry and prints the generated `beta` and `m` values in the legend
area instead.

The overlay for principal on-path binding points is controlled by:

```wl
"RegionOverlayStyle" -> {GrayLevel[.28], Opacity[.7], AbsolutePointSize[1.45]}
"RegionOverlayDataSpacing" -> .045
"RegionOverlayLabel" -> "P on-path binding"
```

The region bodies remain color-filled. Hatching is drawn as thin white, clipped,
plot-coordinate stripes over the colored regions, so it stays legible in
black-and-white and does not change character when `RegionGridSize` is made
finer. Diagonal and vertical hatch spacing are normalized to be visually
comparable.

In the region legend, the binding overlay is shown as a dotted square so that it
matches the dotted overlay in the graph.

For the curve plots, line styles are controlled by:

```wl
"CurveStyleBySeries" -> <|
  "sE" -> Directive[Vermilion, Thick, Dashing[{.035, .018}]],
  "sF" -> Directive[Teal, Thick, Dotted],
  "yF" -> Directive[Teal, Thick],
  "yE" -> Directive[Vermilion, Thick]
|>
```

`sE` is dashed and `sF` is dotted so that exact overlap remains visible in
black-and-white and color output.

Regime panel tick labels are controlled by:

```wl
"CommitmentRegimeLabels" -> {
  1 -> "C-FB",
  2 -> "C-F",
  3 -> "C-P",
  4 -> "C-O"
}

"NoCommitmentRegimeLabels" -> {
  0 -> "NES",
  1 -> "N-0",
  2 -> "N-1",
  ...
  12 -> "S-C"
}
```

The regime panels use these labels twice: as y-axis tick labels and as inline
labels on the step segments. This makes the `N-0`, `S-1`, `C-FB`, etc. codes
visible even when the panel is small.

The actual file uses explicit `RGBColor[...]` values rather than the shorthand
names shown above.

Axis-label sizes are also configured in `Code/FigureStyleConfig.wl`:

```wl
"CurveAxisLabelStyle" -> Directive[Black, FontSize -> 16]
"CurveYRange" -> "MinusMToOne"
"CurveYRangeSafetyMargin" -> .02
"CurveYTicks" -> "MinusMZeroMHalfOne"
"CurveThetaTicks" -> "Eighths"
"CommitmentThetaCurveThetaOverTick" -> True
"ThetaOverTickMinSpacing" -> .055
"ThetaOverGuideStyle" -> Directive[GrayLevel[.35], AbsoluteThickness[.8], Dotted]
"CurveParameterStyle" -> Directive[Black, FontSize -> 15]
"RegimeAxisLabelStyle" -> Directive[Black, FontSize -> 11]
```

`CurveYRange` controls the y-axis scale of the strategy curve plots, including
the standalone `*_curves` exports and the curve panels above the regime strips.
The default `"MinusMToOne"` uses the generated baseline parameter `m` and plots
from `-m - CurveYRangeSafetyMargin` to `1`. Use `All` if you want Mathematica
to choose the y-range automatically, or set an explicit range such as
`{-0.25, 1}`.

The standalone curve plots print `m`, `beta`, and `b` below the curve legend,
using the parameter values stored in the generated curve cache.

With `"CurveYTicks" -> "MinusMZeroMHalfOne"`, curve plots label the y-axis at
`-m`, `0`, `m`, `1/2`, and `1`.

With `"CurveThetaTicks" -> "Eighths"`, theta-curve plots label the x-axis at
`0`, `1/8`, `1/4`, `3/8`, and `1/2`.

With `"CommitmentThetaCurveThetaOverTick" -> True`, the commitment theta-curve
plot additionally labels `\overline{\theta}` on both axes. Nearby regular ticks
are suppressed according to `ThetaOverTickMinSpacing`.
It also draws a thin dotted guide box to `(\overline{\theta},
\overline{\theta})` using `ThetaOverGuideStyle`.

Output size and export switches are still local to:

```text
Code/NoCommitmentPlots.wl
Code/CommitmentPlots.wl
Code/RegionPlots.wl
```

For side-by-side paper figures, the current plot drivers use `ImageSize -> 430`
and larger axis/legend typography. `RegionPlots.wl` uses
`"RasterizeRegionPDF" -> True` and `"RegionRasterImageResolution" -> 600`, so
the region PDFs remain small while staying readable at about `.49\textwidth`.

## Defaults

The baseline comparison parameters are:

- `m = .25`
- `beta = .5`
- `b = .55`
- `theta = .19`

The upper theta grid point is `.5 - 10^-5` because the selector assumptions use
`theta < 1/2`.

Defaults and grid sizes can be changed near the top of:

```text
Code/GenerateFigureData.wl
```

Shared plot colors, hatching, line styles, and labels are changed in:

```text
Code/FigureStyleConfig.wl
```

Output sizes and export switches can be changed near the top of:

```text
Code/NoCommitmentPlots.wl
Code/CommitmentPlots.wl
Code/RegionPlots.wl
```
