(* ::Package:: *)

(* Restore a snapshot from generated_data/<snapshot-name>/ into Code/plot_cache/.
   Usage:
     wolframscript -file Code/RestoreGeneratedDataSnapshot.wl <snapshot-name>
*)

ClearAll["Global`*"];

codeDir = If[StringQ[$InputFileName] && $InputFileName =!= "",
  DirectoryName[$InputFileName],
  NotebookDirectory[]
];

Get[FileNameJoin[{codeDir, "FigureDataWorkflow.wl"}]];

config = FigureWorkflow`figureDefaultConfig[codeDir];
snapshotRoot = FileNameJoin[{config["RepoDir"], "generated_data"}];

say[x__] := WriteString[First[$Output], StringJoin[ToString /@ {x}] <> "\n"];

snapshotNameFromCommandLine[] := If[
  ListQ[$ScriptCommandLine] && Length[$ScriptCommandLine] >= 2,
  $ScriptCommandLine[[2]],
  ""
];

snapshotName = snapshotNameFromCommandLine[];

If[snapshotName === "",
  say["Please provide a snapshot folder name."];
  say["Available snapshots:"];
  If[DirectoryQ[snapshotRoot],
    say /@ FileNameTake /@ Select[FileNames["*", snapshotRoot], DirectoryQ],
    say["  <none; missing ", snapshotRoot, ">"]
  ];
  Abort[];
];

snapshotDir = FileNameJoin[{snapshotRoot, snapshotName}];
If[! DirectoryQ[snapshotDir],
  say["Snapshot not found: ", snapshotDir];
  say["Available snapshots:"];
  If[DirectoryQ[snapshotRoot], say /@ FileNameTake /@ Select[FileNames["*", snapshotRoot], DirectoryQ]];
  Abort[];
];

files = FileNames["*.wxf", snapshotDir];
If[files === {},
  say["No WXF files found in snapshot: ", snapshotDir];
  Abort[];
];

FigureWorkflow`ensureDirectory[config["CacheDir"]];
CopyFile[#, FileNameJoin[{config["CacheDir"], FileNameTake[#]}], OverwriteTarget -> True] & /@ files;

say["Restored generated data snapshot:"];
say[snapshotDir];
say["Into cache directory:"];
say[config["CacheDir"]];
say["Files copied: ", Length[files]];
say["Now run the plotting scripts normally."];
