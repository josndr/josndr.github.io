(* ::Package:: *)

(* Evaluate from GenerateFigureData.nb in the Mathematica front end. *)

ClearAll["Global`*"];

codeDir = If[StringQ[$InputFileName] && $InputFileName =!= "",
  DirectoryName[$InputFileName],
  NotebookDirectory[]
];

Get[FileNameJoin[{codeDir, "FigureDataWorkflow.wl"}]];

baseConfig = FigureWorkflow`figureDefaultConfig[codeDir];

(* ================================================================ *)
(* USER INPUT: ECONOMIC PARAMETERS AND GRIDS                         *)
(* ================================================================ *)
(* Change parameters here, then rerun GenerateFigureData.nb/.wl.
   The plotting notebooks read the cached data produced here. If you only
   change parameters in a plotting file, the underlying data do not change. *)

config = Join[
  baseConfig,
  <|
    "RefreshSelectorDefinitions" -> False,
    "ReuseRegionCache" -> True,

    (* Baseline parameters used for commitment and no-commitment comparison. *)
    "Params" -> <|"m" -> .25, "beta" -> .5, "b" -> .55, "theta" -> .19|>,

    (* Curve and region domains. The upper theta endpoint stays below 1/2
       because the selector assumptions use theta < 1/2. *)
    "ThetaRange" -> {0., .5 - 10^-5},
    "BRange" -> {0., 2},
    "RegionBRange" -> {10^-5, 2},

    (* Numerical resolution. RegionGridSize is the expensive one. *)
    "CurveGridSize" -> 100,
    "RegionGridSize" -> 100
  |>
];

Print["Code directory: ", config["CodeDir"]];
Print["Cache directory: ", config["CacheDir"]];
Print["Parameters: ", config["Params"]];

figureData = FigureWorkflow`generateFigureData[config];

Print["Generated keys: ", Keys[figureData]];
Print["Done. Next evaluate NoCommitmentPlots.nb, CommitmentPlots.nb, or RegionPlots.nb."];
