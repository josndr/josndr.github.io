(* ::Package:: *)

(* Evaluate from CommitmentPlots.nb in the Mathematica front end. *)

ClearAll["Global`*"];

codeDir = If[StringQ[$InputFileName] && $InputFileName =!= "",
  DirectoryName[$InputFileName],
  NotebookDirectory[]
];

Get[FileNameJoin[{codeDir, "FigureDataWorkflow.wl"}]];
Get[FileNameJoin[{codeDir, "FigureStyleConfig.wl"}]];

(* ================================================================ *)
(* USER INPUT: OUTPUT SIZE/EXPORT SWITCHES                          *)
(* ================================================================ *)
(* Economic parameters are set in GenerateFigureData.wl before data are
   generated. Colors and line styles are set once in FigureStyleConfig.wl. *)

config = Join[
  FigureWorkflow`figureDefaultConfig[codeDir],
  figureStyleConfig,
  <|
    "ImageSize" -> figureStyleConfig["PaperFigureImageSize"],
    "AspectRatio" -> figureStyleConfig["PaperFigureAspectRatio"],
    "ExportPDF" -> True,
    "ExportWXF" -> True
  |>
];

data = FigureWorkflow`loadFigureData[config];
FigureWorkflow`assertFigureData[data, {
  "Metadata", "CommitmentThetaCurves", "CommitmentBCurves",
  "CommitmentThetaRegime", "CommitmentBRegime"
}];

commitmentThetaCurves =
  FigureWorkflow`commitmentCurvePlot[data, config, "CommitmentThetaCurves"];
commitmentThetaRegime =
  FigureWorkflow`regimeStepPlot[data, config, "CommitmentThetaRegime",
    config["CommitmentRegimeLabels"]];
commitmentBCurves =
  FigureWorkflow`commitmentCurvePlot[data, config, "CommitmentBCurves"];
commitmentBRegime =
  FigureWorkflow`regimeStepPlot[data, config, "CommitmentBRegime",
    config["CommitmentRegimeLabels"]];

commitmentThetaPanel = Column[{commitmentThetaCurves, commitmentThetaRegime}, Spacings -> .2];
commitmentBPanel = Column[{commitmentBCurves, commitmentBRegime}, Spacings -> .2];

FigureWorkflow`exportGraphicsSet[
  <|
    "theta_panel" -> commitmentThetaPanel,
    "b_panel" -> commitmentBPanel,
    "theta_curves" -> commitmentThetaCurves,
    "b_curves" -> commitmentBCurves
  |>,
  config,
  "commitment"
];

Print["Commitment plots ready."];
commitmentThetaPanel
commitmentBPanel
