(* ::Package:: *)

(* Evaluate from NoCommitmentPlots.nb in the Mathematica front end. *)

ClearAll["Global`*"];

codeDir = If[StringQ[$InputFileName] && $InputFileName =!= "",
  DirectoryName[$InputFileName],
  NotebookDirectory[]
];

Get[FileNameJoin[{codeDir, "FigureDataWorkflow.wl"}]];
Get[FileNameJoin[{codeDir, "FigureStyleConfig.wl"}]];

(* ================================================================ *)
(* USER INPUT: OUTPUT SIZE/EXPORT SWITCHES                          *)
(* ================================================================ *)
(* Economic parameters are set in GenerateFigureData.wl before data are
   generated. Colors and line styles are set once in FigureStyleConfig.wl. *)

config = Join[
  FigureWorkflow`figureDefaultConfig[codeDir],
  figureStyleConfig,
  <|
    "ImageSize" -> figureStyleConfig["PaperFigureImageSize"],
    "AspectRatio" -> figureStyleConfig["PaperFigureAspectRatio"],
    "ExportPDF" -> True,
    "ExportWXF" -> True
  |>
];

data = FigureWorkflow`loadFigureData[config];
FigureWorkflow`assertFigureData[data, {
  "Metadata", "NoCommitmentThetaCurves", "NoCommitmentBCurves",
  "NoCommitmentThetaRegime", "NoCommitmentBRegime"
}];

noCommitmentThetaCurves =
  FigureWorkflow`noCommitmentCurvePlot[data, config, "NoCommitmentThetaCurves"];
noCommitmentThetaRegime =
  FigureWorkflow`regimeStepPlot[data, config, "NoCommitmentThetaRegime",
    config["NoCommitmentRegimeLabels"]];
noCommitmentBCurves =
  FigureWorkflow`noCommitmentCurvePlot[data, config, "NoCommitmentBCurves"];
noCommitmentBRegime =
  FigureWorkflow`regimeStepPlot[data, config, "NoCommitmentBRegime",
    config["NoCommitmentRegimeLabels"]];

noCommitmentThetaPanel = Column[{noCommitmentThetaCurves, noCommitmentThetaRegime}, Spacings -> .2];
noCommitmentBPanel = Column[{noCommitmentBCurves, noCommitmentBRegime}, Spacings -> .2];

FigureWorkflow`exportGraphicsSet[
  <|
    "theta_panel" -> noCommitmentThetaPanel,
    "b_panel" -> noCommitmentBPanel,
    "theta_curves" -> noCommitmentThetaCurves,
    "b_curves" -> noCommitmentBCurves
  |>,
  config,
  "no_commitment"
];

Print["No-commitment plots ready."];
noCommitmentThetaPanel
noCommitmentBPanel
