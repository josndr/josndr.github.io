(* ::Package:: *)

(* Save the current Code/plot_cache data into a parameter-named folder under
   generated_data/. Run this after GenerateFigureData.wl. *)

ClearAll["Global`*"];

codeDir = If[StringQ[$InputFileName] && $InputFileName =!= "",
  DirectoryName[$InputFileName],
  NotebookDirectory[]
];

Get[FileNameJoin[{codeDir, "FigureDataWorkflow.wl"}]];

config = FigureWorkflow`figureDefaultConfig[codeDir];

say[x__] := WriteString[First[$Output], StringJoin[ToString /@ {x}] <> "\n"];

(* USER INPUT *)
snapshotRoot = FileNameJoin[{config["RepoDir"], "generated_data"}];
overwriteExisting = False;

safeNumber[x_] := StringReplace[
  ToString[NumberForm[N[x], {10, 5}, NumberPoint -> ".", ExponentFunction -> (Null &)]],
  {" " -> "", "." -> "p", "-" -> "m"}
];

rangeToken[name_String, range_List] := name <> safeNumber[range[[1]]] <> "-" <> safeNumber[range[[2]]];

snapshotNameFromMetadata[metadata_Association] := Module[{params},
  params = metadata["Params"];
  StringRiffle[
    {
      "m" <> safeNumber[params["m"]],
      "beta" <> safeNumber[params["beta"]],
      "b" <> safeNumber[params["b"]],
      "theta" <> safeNumber[params["theta"]],
      "curveGrid" <> ToString[metadata["CurveGridSize"]],
      "regionGrid" <> ToString[metadata["RegionGridSize"]],
      rangeToken["theta", metadata["ThetaRange"]],
      rangeToken["b", metadata["BRange"]],
      rangeToken["regionB", metadata["RegionBRange"]]
    },
    "__"
  ]
];

data = FigureWorkflow`loadFigureData[config];
FigureWorkflow`assertFigureData[data, {"Metadata"}];

metadata = data["Metadata"];
snapshotName = snapshotNameFromMetadata[metadata];
snapshotDir = FileNameJoin[{snapshotRoot, snapshotName}];

If[DirectoryQ[snapshotDir] && ! TrueQ[overwriteExisting],
  say["Snapshot already exists: ", snapshotDir];
  say["Set overwriteExisting = True in SaveGeneratedDataSnapshot.wl if you want to replace it."];
  Abort[];
];

If[! DirectoryQ[snapshotRoot], CreateDirectory[snapshotRoot, CreateIntermediateDirectories -> True]];
If[! DirectoryQ[snapshotDir], CreateDirectory[snapshotDir, CreateIntermediateDirectories -> True]];

files = FileNames["*.wxf", config["CacheDir"]];
If[files === {},
  say["No WXF cache files found in: ", config["CacheDir"]];
  Abort[];
];

CopyFile[#, FileNameJoin[{snapshotDir, FileNameTake[#]}], OverwriteTarget -> True] & /@ files;

manifest = Join[
  metadata,
  <|
    "SavedAt" -> DateString[{"ISODate", " ", "Time"}],
    "SnapshotName" -> snapshotName,
    "SnapshotDir" -> snapshotDir,
    "SourceCacheDir" -> config["CacheDir"]
  |>
];

Export[FileNameJoin[{snapshotDir, "manifest.wl"}], ToString[InputForm[manifest]], "Text"];
Export[
  FileNameJoin[{snapshotDir, "README.txt"}],
  "Generated data snapshot for the figure workflow.\n\n" <>
    "To use it, run:\n" <>
    "  wolframscript -file Code/RestoreGeneratedDataSnapshot.wl " <> snapshotName <> "\n\n" <>
    "Then run the plotting scripts normally.\n",
  "Text"
];

say["Saved generated data snapshot:"];
say[snapshotDir];
say["Files copied: ", Length[files]];
