(* ::Package:: *)

(* Central figure style choices.
   Edit this file when colors, line styles, labels, or region hatching should
   change across all generated graphs. *)

figureStyleConfig = <|
  "Colors" -> <|
    "Amber" -> RGBColor[1., 191/255, 0.],
    "Vermilion" -> RGBColor[227/255, 85/255, 10/255],
    "BluishGreen" -> RGBColor[0., 158/255, 115/255],
    "Teal" -> RGBColor[0., 128/255, 128/255],
    "Black" -> Black,
    "White" -> White
  |>,

  (* Region class codes:
     -9 no match, 0 NES, 1 full embracing, 2 partial embracing,
      3 opportunism, 4 first best. No match is intentionally omitted from the
      legend by RegionClassOrder. *)
  "RegionClassOrder" -> {4, 1, 2, 3, 0},
  "CommitmentRegionClassOrder" -> {4, 1, 2, 3},
  "RegionClassLabels" -> <|
    4 -> "first best",
    1 -> "full embracing",
    2 -> "partial embracing",
    3 -> "opportunism",
    0 -> "NES",
    -9 -> "no match"
  |>,
  "RegionClassColors" -> <|
    4 -> RGBColor[1., 191/255, 0.],
    1 -> RGBColor[227/255, 85/255, 10/255],
    2 -> White,
    3 -> RGBColor[0., 158/255, 115/255],
    0 -> Black,
    -9 -> White
  |>,
  "RegionHatches" -> <|
    1 -> "NorthEast",
    3 -> "Vertical"
  |>,
  "RegionHatchLineColors" -> <|
    1 -> White,
    3 -> White
  |>,
  "RegionHatchedClassesUseColorFill" -> True,
  "RegionHatchFillColor" -> White,
  "RegionHatchOpacity" -> .85,
  "RegionHatchThickness" -> .45,
  "RegionHatchStride" -> 3,
  "RegionHatchDataSpacing" -> .0125,
  "RegionHatchSampleCount" -> 650,
  "RegionOverlayStyle" -> {GrayLevel[.18], Opacity[.75], AbsolutePointSize[1.55]},
  "RegionOverlayStride" -> 5,
  "RegionOverlayDataSpacing" -> .004,
  "RegionOverlayLabel" -> "P on-path binding",
  "RegionLegendPlacement" -> Below,
  "RegionLegendColumns" -> 2,
  "RegionLegendStyle" -> Directive[Black, FontSize -> 16],
  "RegionLegendSwatchSize" -> {22, 22},
  "RegionAxisLabelStyle" -> Directive[Black, FontSize -> 22],
  "RegionTickLabelStyle" -> Directive[Black, FontSize -> 16],
  "RegionImagePadding" -> {{62, 14}, {58, 12}},

  (* Strategy curve order and styles. These keys match generated data:
     sE, sF, yF, yE. *)
  "CurveSeriesOrder" -> {"sE", "sF", "yF", "yE"},
  "CurveLabelBySeries" -> <|
    "sE" -> "\!\(\*SubscriptBox[\(s\), \(E\)]\)",
    "sF" -> "\!\(\*SubscriptBox[\(s\), \(F\)]\)",
    "yF" -> "\!\(\*SuperscriptBox[SubscriptBox[\(y\), \(F\)], \(*\)]\)",
    "yE" -> "\!\(\*SuperscriptBox[SubscriptBox[\(y\), \(E\)], \(*\)]\)"
  |>,
  "CurveStyleBySeries" -> <|
    "sE" -> Directive[RGBColor[227/255, 85/255, 10/255], AbsoluteThickness[2.2], Dashing[{.035, .018}]],
    "sF" -> Directive[RGBColor[0., 128/255, 128/255], AbsoluteThickness[2.2], Dotted],
    "yF" -> Directive[RGBColor[0., 128/255, 128/255], AbsoluteThickness[2.4]],
    "yE" -> Directive[RGBColor[227/255, 85/255, 10/255], AbsoluteThickness[2.4]]
  |>,

  "CommitmentRegimeLabels" -> {
    1 -> "C-FB",
    2 -> "C-F",
    3 -> "C-P",
    4 -> "C-O"
  },
  "NoCommitmentRegimeLabels" -> {
    0 -> "NES",
    1 -> "N-0",
    2 -> "N-1",
    3 -> "N-2",
    4 -> "S-0",
    5 -> "S-1",
    6 -> "S-2",
    7 -> "N-A",
    8 -> "N-B",
    9 -> "N-C",
    10 -> "S-A",
    11 -> "S-B",
    12 -> "S-C"
  },
  "PlotBaseStyle" -> Directive[Black, FontFamily -> "Times", FontSize -> 16],
  "FrameStyle" -> Directive[Black, AbsoluteThickness[1.1]],
  "PaperFigureImageSize" -> 430,
  "PaperFigureAspectRatio" -> .7,
  "PaperFigureImagePadding" -> {{62, 14}, {58, 12}},
  "PlotLabelStyle" -> Directive[Black, FontSize -> 20],
  "CurveAxisLabelStyle" -> Directive[Black, FontSize -> 22],
  "CurveTickLabelStyle" -> Directive[Black, FontSize -> 16],
  "CurveLegendStyle" -> Directive[Black, FontSize -> 17],
  "CurveParameterStyle" -> Directive[Black, FontSize -> 15],
  "CurveLegendMarkerSize" -> 28,
  "CurveImagePadding" -> {{62, 14}, {58, 12}},
  "CurveYRange" -> "MinusMToOne",
  "CurveYRangeSafetyMargin" -> .02,
  "CurveYTicks" -> "MinusMZeroMHalfOne",
  "CurveThetaTicks" -> "Eighths",
  "CommitmentThetaCurveThetaOverTick" -> True,
  "ThetaOverTickMinSpacing" -> .055,
  "ThetaOverGuideStyle" -> Directive[GrayLevel[.35], AbsoluteThickness[.8], Dotted],
  "RegimeAxisLabelStyle" -> Directive[Black, FontSize -> 11],
  "RegimeTickLabelStyle" -> Directive[Black, FontSize -> 8],
  "RegimeInlineLabelStyle" -> Directive[Black, FontSize -> 8],

  "AxisLabels" -> <|
    "theta" -> "\[Theta]",
    "b" -> "b"
  |>
|>;
