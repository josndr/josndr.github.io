(* ::Package:: *)

(* Evaluate from RegionPlots.nb in the Mathematica front end. *)

ClearAll["Global`*"];

codeDir = If[StringQ[$InputFileName] && $InputFileName =!= "",
  DirectoryName[$InputFileName],
  NotebookDirectory[]
];

Get[FileNameJoin[{codeDir, "FigureDataWorkflow.wl"}]];
Get[FileNameJoin[{codeDir, "FigureStyleConfig.wl"}]];

(* ================================================================ *)
(* USER INPUT: OUTPUT SIZE/EXPORT SWITCHES                          *)
(* ================================================================ *)
(* Economic parameters are set in GenerateFigureData.wl before data are
   generated. Region colors and hatching are set once in FigureStyleConfig.wl. *)

config = Join[
  FigureWorkflow`figureDefaultConfig[codeDir],
  figureStyleConfig,
  <|
    "ImageSize" -> figureStyleConfig["PaperFigureImageSize"],
    "AspectRatio" -> figureStyleConfig["PaperFigureAspectRatio"],
    "RasterizeRegionPDF" -> True,
    "RegionRasterImageResolution" -> 600,
    "ExportPDF" -> True,
    "ExportWXF" -> True
  |>
];

data = FigureWorkflow`loadFigureData[config];
FigureWorkflow`assertFigureData[data, {"Metadata", "NoCommitmentRegionThetaB", "CommitmentRegionThetaB"}];

noCommitmentRegionThetaB = FigureWorkflow`regionThetaBPlot[data, config];
commitmentRegionThetaB = FigureWorkflow`commitmentRegionThetaBPlot[data, config];

exportDir = FigureWorkflow`ensureDirectory[config["ExportDir"]];

If[TrueQ[config["ExportPDF"]],
  Export[
    FileNameJoin[{exportDir, "regions_theta_b.pdf"}],
    If[TrueQ[config["RasterizeRegionPDF"]],
      Rasterize[noCommitmentRegionThetaB, ImageResolution -> config["RegionRasterImageResolution"]],
      noCommitmentRegionThetaB
    ],
    "PDF"
  ];
  Export[
    FileNameJoin[{exportDir, "commitment_regions_theta_b.pdf"}],
    If[TrueQ[config["RasterizeRegionPDF"]],
      Rasterize[commitmentRegionThetaB, ImageResolution -> config["RegionRasterImageResolution"]],
      commitmentRegionThetaB
    ],
    "PDF"
  ];
];

If[TrueQ[config["ExportWXF"]],
  Export[
    FileNameJoin[{exportDir, "regions_theta_b.wxf"}],
    noCommitmentRegionThetaB,
    "WXF"
  ];
  Export[
    FileNameJoin[{exportDir, "commitment_regions_theta_b.wxf"}],
    commitmentRegionThetaB,
    "WXF"
  ];
];

Print["Region plots ready."];
Column[{noCommitmentRegionThetaB, commitmentRegionThetaB}, Spacings -> .6]
