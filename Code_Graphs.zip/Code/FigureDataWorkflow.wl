(* ::Package:: *)

(* Shared data-generation and plotting helpers for the commitment/no-commitment figures.
   This file is intended to be loaded from Mathematica notebooks in the front end. *)

ClearAll["Global`FigureWorkflow`*"];
BeginPackage["FigureWorkflow`"];

figureDefaultConfig::usage = "figureDefaultConfig[baseDir] returns default parameters, grids, and output paths.";
ensureDirectory::usage = "ensureDirectory[path] creates path if needed and returns it.";
loadSelectorDefinitions::usage = "loadSelectorDefinitions[config] loads saved selector definitions, optionally regenerating them.";
generateFigureData::usage = "generateFigureData[config] samples selector values and exports WXF data caches.";
loadFigureData::usage = "loadFigureData[config] imports generated WXF data caches.";
assertFigureData::usage = "assertFigureData[data, keys] aborts if required data keys are missing.";

noCommitmentCurvePlot::usage = "noCommitmentCurvePlot[data, config, key] plots no-commitment curve data.";
commitmentCurvePlot::usage = "commitmentCurvePlot[data, config, key] plots commitment curve data.";
regimeStepPlot::usage = "regimeStepPlot[data, config, key, labels] plots sampled regime/class data.";
regionThetaBPlot::usage = "regionThetaBPlot[data, config] plots the no-commitment region grid.";
commitmentRegionThetaBPlot::usage = "commitmentRegionThetaBPlot[data, config] plots the commitment region grid.";
exportGraphicsSet::usage = "exportGraphicsSet[graphicsAssoc, config, stem] exports PDF and WXF graphics.";

Begin["`Private`"];

ensureDirectory[path_String] := If[DirectoryQ[path], path, CreateDirectory[path, CreateIntermediateDirectories -> True]];

figureDefaultConfig[baseDir_String : Automatic] := Module[{codeDir, repoDir},
  codeDir = If[baseDir === Automatic, NotebookDirectory[], baseDir];
  repoDir = DirectoryName[codeDir];
  <|
    "Version" -> 1,
    "CodeDir" -> codeDir,
    "RepoDir" -> repoDir,
    "CacheDir" -> FileNameJoin[{codeDir, "plot_cache"}],
    "ExportDir" -> FileNameJoin[{repoDir, "Graphs", "generated"}],
    "SelectorCacheMX" -> FileNameJoin[{codeDir, "partial_nc_selector_cache.mx"}],
    "SelectorCacheWL" -> FileNameJoin[{codeDir, "partial_nc_selector_cache.wl"}],
    "LegacyNoCommitmentSource" -> FileNameJoin[{codeDir, "PartialNonCommitmentCleaner.nb"}],
    "RefreshSelectorDefinitions" -> False,
    "Params" -> <|"m" -> .2, "beta" -> .6, "b" -> .45, "theta" -> .12|>,
    "ThetaRange" -> {0., .5 - 10^-5},
    "BRange" -> {0., 8.},
    "RegionBRange" -> {10^-5, 2.5},
    "CurveGridSize" -> 301,
    "RegionGridSize" -> 151,
    "ReuseRegionCache" -> True,
    "ImageSize" -> 520,
    "AspectRatio" -> .62,
    "PlotTheme" -> "Monochrome",
    "CurveStyles" -> {
      Directive[Black, Thick],
      Directive[Black, Thick, Dashed],
      Directive[GrayLevel[.35], Thick, Dotted],
      Directive[GrayLevel[.35], Thick, DotDashed]
    },
    "CurveLabels" -> {"s_F", "s_E", "y_E", "y_F"},
    "RegionClassOrder" -> {-9, 0, 1, 2, 3, 4},
    "RegionClassLabels" -> <|
      -9 -> "no match",
      0 -> "NES",
      1 -> "full",
      2 -> "partial",
      3 -> "opportunistic",
      4 -> "first best"
    |>,
    "RegionClassColors" -> <|
      -9 -> GrayLevel[.82],
      0 -> GrayLevel[.18],
      1 -> RGBColor[.90, .90, .90],
      2 -> RGBColor[1., 1., 1.],
      3 -> GrayLevel[.58],
      4 -> GrayLevel[.72]
    |>,
    "RegionOverlayStyle" -> {Black, Opacity[.6], AbsolutePointSize[1.2]},
    "ExportPDF" -> True,
    "ExportWXF" -> True
  |>
];

mergeConfig[a_Association, b_Association] := Merge[{a, b}, Last];

clearSelectorDefinitions[] := ClearAll[
  Global`ncPolicyVector,
  Global`ncClass,
  Global`commitmentPolicy
];

selectorDefinitionsLoadedQ[] := (
  Length[DownValues[Global`ncPolicyVector]] > 0 &&
  Length[DownValues[Global`ncClass]] > 0 &&
  Length[DownValues[Global`commitmentPolicy]] > 0
);

loadSelectorCacheFile[file_String] := Module[{loaded},
  If[! FileExistsQ[file], Return[False]];
  Print["Loading selector definitions from: ", file];
  clearSelectorDefinitions[];
  loaded = Quiet[Check[Get[file]; True, False]];
  If[TrueQ[loaded] && selectorDefinitionsLoadedQ[], Return[True]];
  Print["Selector file could not be used: ", file];
  False
];

refreshSelectorDefinitionsFromSource[source_String] := Module[{extension},
  If[! FileExistsQ[source], Print["Missing source file: ", source]; Abort[]];
  extension = ToLowerCase[FileExtension[source]];
  clearSelectorDefinitions[];
  Print["Refreshing selector definitions from legacy source: ", source];
  Block[{$Context = "Global`", $ContextPath = {"System`", "Global`"}},
    If[extension === "nb",
      Print["Evaluating notebook with NotebookEvaluate. This requires a notebook-capable Wolfram installation."];
      NotebookEvaluate[source, InsertResults -> False],
      Get[source]
    ]
  ];
  If[! selectorDefinitionsLoadedQ[],
    Print["Legacy source did not define ncPolicyVector/ncClass/commitmentPolicy."];
    Print["For notebook refreshes, evaluate Code/PartialNonCommitmentCleaner.nb in Mathematica Desktop or provide a refreshed selector cache."];
    Abort[]
  ];
  True
];

loadSelectorDefinitions[config_Association] := Module[{mx, wl, source},
  mx = config["SelectorCacheMX"];
  wl = config["SelectorCacheWL"];
  source = config["LegacyNoCommitmentSource"];
  If[TrueQ[Lookup[config, "RefreshSelectorDefinitions", False]],
    refreshSelectorDefinitionsFromSource[source],
    If[! loadSelectorCacheFile[mx] && ! loadSelectorCacheFile[wl],
      Print["No usable selector cache found. Set RefreshSelectorDefinitions -> True after confirming the legacy notebook can run in Mathematica Desktop."];
      Abort[]
    ]
  ];
  True
];

realize[x_] := Module[{v = Quiet@Check[N[x], Indeterminate]},
  If[NumericQ[v] && TrueQ[PossibleZeroQ[Im[v]]], Re[v], Indeterminate]
];

policyValue[f_, args___] := Quiet@Check[realize[f[args]], Indeterminate];
policyVectorValue[f_, args___] := Module[{v = Quiet@Check[f[args], $Failed]},
  If[ListQ[v], realize /@ v, ConstantArray[Indeterminate, 6]]
];

commitmentClassFromPolicy[pol_] := Module[{type},
  If[! AssociationQ[pol], Return[-9]];
  type = Lookup[pol, "type", ""];
  Which[
    StringContainsQ[type, "FB"], 4,
    StringContainsQ[type, "full"], 1,
    StringContainsQ[type, "partial"], 2,
    StringContainsQ[type, "opportunistic"], 3,
    True, -9
  ]
];

commitmentRegimeNumber[pol_] := Module[{type},
  If[! AssociationQ[pol], Return[Indeterminate]];
  type = Lookup[pol, "type", ""];
  Which[
    StringContainsQ[type, "FB"], 1,
    StringContainsQ[type, "full"], 2,
    StringContainsQ[type, "partial"], 3,
    StringContainsQ[type, "opportunistic"], 4,
    True, Indeterminate
  ]
];

commitmentPolicyVector[mm_, bbeta_, bb_, ttheta_] := Module[{pol},
  pol = Quiet@Check[Global`commitmentPolicy[mm, bbeta, ttheta, bb], Missing["NoPolicy"]];
  If[AssociationQ[pol],
    {commitmentRegimeNumber[pol], pol["sF"], pol["sE"], pol["yF"], pol["yE"], commitmentClassFromPolicy[pol]},
    {Indeterminate, Indeterminate, Indeterminate, Indeterminate, Indeterminate, -9}
  ]
];

seriesAssociation[axis_, labels_, matrix_] := AssociationThread[labels, Transpose[matrix]];

makeCurveData[axis_, matrix_, params_, xLabel_] := <|
  "Axis" -> axis,
  "Series" -> seriesAssociation[axis, {"sF", "sE", "yE", "yF"}, matrix[[All, {1, 2, 4, 3}]]],
  "Params" -> params,
  "XLabel" -> xLabel
|>;

gridEqualQ[a_, b_, tol_ : 10^-10] := Module[{na, nb},
  na = N[a]; nb = N[b];
  ListQ[na] && ListQ[nb] && Length[na] == Length[nb] &&
    If[Length[na] == 0, True, Max[Abs[na - nb]] <= tol]
];

sameRegionParametersQ[cachedParams_Association, params_Association, tol_ : 10^-10] := And[
  KeyExistsQ[cachedParams, "m"],
  KeyExistsQ[cachedParams, "beta"],
  Abs[N[cachedParams["m"] - params["m"]]] <= tol,
  Abs[N[cachedParams["beta"] - params["beta"]]] <= tol
];

regionCacheValidQ[region_, params_Association, thetaGrid_List, bGrid_List, requiredKeys_List] := Module[
  {classDims},
  If[! AssociationQ[region], Return[False]];
  If[! And @@ (KeyExistsQ[region, #] & /@ Join[{"ThetaGrid", "BGrid", "ClassGrid", "Params"}, requiredKeys]), Return[False]];
  If[! AssociationQ[region["Params"]], Return[False]];
  If[! sameRegionParametersQ[region["Params"], params], Return[False]];
  If[! gridEqualQ[region["ThetaGrid"], thetaGrid] || ! gridEqualQ[region["BGrid"], bGrid], Return[False]];
  classDims = Dimensions[region["ClassGrid"]];
  classDims === {Length[thetaGrid], Length[bGrid]}
];

loadCachedRegion[config_Association, key_String] := Module[{file},
  file = FileNameJoin[{config["CacheDir"], key <> ".wxf"}];
  If[FileExistsQ[file], Quiet@Check[Import[file], Missing["BadRegionCache"]], Missing["NoRegionCache"]]
];

regionWithCurrentParams[region_Association, params_Association] := Join[region, <|"Params" -> params|>];

generateFigureData[config0_Association] := Module[
  {config = config0, params, cacheDir, thetaGrid, bGrid, regionThetaGrid, regionBGrid,
   mm, bbeta, bb, ttheta, ncThetaMatrix, ncBMatrix, cThetaMatrix, cBMatrix,
   ncThetaRegime, ncBRegime, cThetaRegime, cBRegime, ncRegionPolicy, ncRegionClass,
   cRegionClass, pBindGrid, pBindRegimes, ncRegionAssoc, cRegionAssoc, cachedNCRegion,
   cachedCRegion, reuseRegions, data, metadata, files},

  ensureDirectory[config["CacheDir"]];
  ensureDirectory[config["ExportDir"]];
  loadSelectorDefinitions[config];

  params = config["Params"];
  {mm, bbeta, bb, ttheta} = params /@ {"m", "beta", "b", "theta"};
  thetaGrid = N @ Subdivide[config["ThetaRange"][[1]], config["ThetaRange"][[2]], config["CurveGridSize"] - 1];
  bGrid = N @ Subdivide[config["BRange"][[1]], config["BRange"][[2]], config["CurveGridSize"] - 1];
  regionThetaGrid = N @ Subdivide[config["ThetaRange"][[1]], config["ThetaRange"][[2]], config["RegionGridSize"] - 1];
  regionBGrid = N @ Subdivide[config["RegionBRange"][[1]], config["RegionBRange"][[2]], config["RegionGridSize"] - 1];

  Print["Sampling no-commitment theta curves..."];
  ncThetaMatrix = Table[policyVectorValue[Global`ncPolicyVector, mm, bbeta, bb, th][[2 ;; 5]], {th, thetaGrid}];
  ncThetaRegime = Table[policyVectorValue[Global`ncPolicyVector, mm, bbeta, bb, th][[1]], {th, thetaGrid}];

  Print["Sampling no-commitment b curves..."];
  ncBMatrix = Table[policyVectorValue[Global`ncPolicyVector, mm, bbeta, bval, ttheta][[2 ;; 5]], {bval, bGrid}];
  ncBRegime = Table[policyVectorValue[Global`ncPolicyVector, mm, bbeta, bval, ttheta][[1]], {bval, bGrid}];

  Print["Sampling commitment theta curves..."];
  cThetaMatrix = Table[commitmentPolicyVector[mm, bbeta, bb, th][[2 ;; 5]], {th, thetaGrid}];
  cThetaRegime = Table[commitmentPolicyVector[mm, bbeta, bb, th][[1]], {th, thetaGrid}];

  Print["Sampling commitment b curves..."];
  cBMatrix = Table[commitmentPolicyVector[mm, bbeta, bval, ttheta][[2 ;; 5]], {bval, bGrid}];
  cBRegime = Table[commitmentPolicyVector[mm, bbeta, bval, ttheta][[1]], {bval, bGrid}];

  reuseRegions = TrueQ[Lookup[config, "ReuseRegionCache", True]];

  cachedNCRegion = If[reuseRegions, loadCachedRegion[config, "NoCommitmentRegionThetaB"], Missing["ReuseDisabled"]];
  If[reuseRegions && regionCacheValidQ[cachedNCRegion, params, regionThetaGrid, regionBGrid, {"PolicyGrid", "PBindGrid"}],
    Print["WARNING: Reusing no-commitment region grid cache. Baseline b/theta changes do not affect this grid."];
    ncRegionAssoc = regionWithCurrentParams[cachedNCRegion, params],
    Print["Sampling no-commitment region grid..."];
    ncRegionPolicy = Table[policyVectorValue[Global`ncPolicyVector, mm, bbeta, bval, th], {th, regionThetaGrid}, {bval, regionBGrid}];
    ncRegionClass = Table[Global`ncClass[mm, bbeta, bval, th], {th, regionThetaGrid}, {bval, regionBGrid}];
    pBindRegimes = {1, 2, 4, 5};
    pBindGrid = Map[Boole[MemberQ[pBindRegimes, Round[#[[1]]]]] &, ncRegionPolicy, {2}];
    ncRegionAssoc = <|"ThetaGrid" -> regionThetaGrid, "BGrid" -> regionBGrid, "ClassGrid" -> ncRegionClass, "PolicyGrid" -> ncRegionPolicy, "PBindGrid" -> pBindGrid, "Params" -> params|>
  ];

  cachedCRegion = If[reuseRegions, loadCachedRegion[config, "CommitmentRegionThetaB"], Missing["ReuseDisabled"]];
  If[reuseRegions && regionCacheValidQ[cachedCRegion, params, regionThetaGrid, regionBGrid, {}],
    Print["WARNING: Reusing commitment region grid cache. Baseline b/theta changes do not affect this grid."];
    cRegionAssoc = regionWithCurrentParams[cachedCRegion, params],
    Print["Sampling commitment region grid..."];
    cRegionClass = Table[
      commitmentPolicyVector[mm, bbeta, bval, th][[6]],
      {th, regionThetaGrid},
      {bval, regionBGrid}
    ];
    cRegionAssoc = <|"ThetaGrid" -> regionThetaGrid, "BGrid" -> regionBGrid, "ClassGrid" -> cRegionClass, "Params" -> params|>
  ];

  metadata = <|
    "GeneratedAt" -> DateString[{"ISODate", " ", "Time"}],
    "WorkflowVersion" -> config["Version"],
    "Params" -> params,
    "CurveGridSize" -> config["CurveGridSize"],
    "RegionGridSize" -> config["RegionGridSize"],
    "ThetaRange" -> config["ThetaRange"],
    "BRange" -> config["BRange"],
    "RegionBRange" -> config["RegionBRange"]
  |>;

  data = <|
    "Metadata" -> metadata,
    "NoCommitmentThetaCurves" -> makeCurveData[thetaGrid, ncThetaMatrix, params, "theta"],
    "NoCommitmentBCurves" -> makeCurveData[bGrid, ncBMatrix, params, "b"],
    "NoCommitmentThetaRegime" -> <|"Axis" -> thetaGrid, "Values" -> ncThetaRegime, "Params" -> params, "XLabel" -> "theta"|>,
    "NoCommitmentBRegime" -> <|"Axis" -> bGrid, "Values" -> ncBRegime, "Params" -> params, "XLabel" -> "b"|>,
    "CommitmentThetaCurves" -> makeCurveData[thetaGrid, cThetaMatrix, params, "theta"],
    "CommitmentBCurves" -> makeCurveData[bGrid, cBMatrix, params, "b"],
    "CommitmentThetaRegime" -> <|"Axis" -> thetaGrid, "Values" -> cThetaRegime, "Params" -> params, "XLabel" -> "theta"|>,
    "CommitmentBRegime" -> <|"Axis" -> bGrid, "Values" -> cBRegime, "Params" -> params, "XLabel" -> "b"|>,
    "NoCommitmentRegionThetaB" -> ncRegionAssoc,
    "CommitmentRegionThetaB" -> cRegionAssoc
  |>;

  files = AssociationMap[FileNameJoin[{config["CacheDir"], # <> ".wxf"}] &, Keys[data]];
  KeyValueMap[Export[#2, data[#1], "WXF"] &, files];
  Export[FileNameJoin[{config["CacheDir"], "figure_data_bundle.wxf"}], data, "WXF"];
  Print["Data exported to: ", config["CacheDir"]];
  data
];

loadFigureData[config_Association] := Module[{bundle, keys, data},
  bundle = FileNameJoin[{config["CacheDir"], "figure_data_bundle.wxf"}];
  If[FileExistsQ[bundle], Return[Import[bundle]]];
  keys = {"Metadata", "NoCommitmentThetaCurves", "NoCommitmentBCurves", "NoCommitmentThetaRegime",
    "NoCommitmentBRegime", "CommitmentThetaCurves", "CommitmentBCurves", "CommitmentThetaRegime",
    "CommitmentBRegime", "NoCommitmentRegionThetaB", "CommitmentRegionThetaB"};
  data = Association @ Table[k -> Import[FileNameJoin[{config["CacheDir"], k <> ".wxf"}]], {k, keys}];
  data
];

assertFigureData[data_Association, keys_List] := Module[{missing},
  missing = Select[keys, ! KeyExistsQ[data, #] || data[#] === $Failed || Head[data[#]] === Failure &];
  If[missing =!= {}, Print["Missing generated data keys: ", missing]; Abort[]];
  Print["Sanity check passed for keys: ", keys];
  True
];

axisLabel[x_, config_Association] := Lookup[Lookup[config, "AxisLabels", <||>], x, x];

styledAxisLabel[x_, config_Association, styleKey_String] := Style[
  axisLabel[x, config],
  Lookup[config, styleKey, Directive[Black, FontSize -> 12]]
];

curveSeriesOrder[series_Association, config_Association] := Select[
  Lookup[config, "CurveSeriesOrder", Keys[series]],
  KeyExistsQ[series, #] &
];

curveStyleFor[key_, config_Association] := Lookup[
  Lookup[config, "CurveStyleBySeries", <||>],
  key,
  Directive[Black, Thick]
];

curveLabelFor[key_, config_Association] := Lookup[
  Lookup[config, "CurveLabelBySeries", <||>],
  key,
  key
];

curveYRange[curveData_Association, config_Association] := Module[{setting, params, m, margin},
  setting = Lookup[config, "CurveYRange", All];
  If[setting =!= "MinusMToOne", Return[setting]];
  params = Lookup[curveData, "Params", Lookup[config, "Params", <||>]];
  m = Lookup[params, "m", Missing["m"]];
  margin = Lookup[config, "CurveYRangeSafetyMargin", .02];
  If[NumericQ[m], {-m - margin, 1}, All]
];

curveYTicks[curveData_Association, config_Association] := Module[{setting, params, m, style},
  setting = Lookup[config, "CurveYTicks", Automatic];
  If[setting =!= "MinusMZeroMHalfOne", Return[setting]];
  params = Lookup[curveData, "Params", Lookup[config, "Params", <||>]];
  m = Lookup[params, "m", Missing["m"]];
  style = Lookup[config, "CurveTickLabelStyle", Directive[Black, FontSize -> 12]];
  If[NumericQ[m],
    {
      {-m, Style["-m", style]},
      {0, Style["0", style]},
      {m, Style["m", style]},
      {1/2, Style["1/2", style]},
      {1, Style["1", style]}
    },
    Automatic
  ]
];

addThetaOverTick[ticks_, curveData_Association, config_Association] := Module[{params, cutoffs, thetaOver, style, tick, minSpacing, thinnedTicks},
  If[! TrueQ[Lookup[config, "AddThetaOverTick", False]], Return[ticks]];
  If[Lookup[curveData, "XLabel", ""] =!= "theta", Return[ticks]];
  params = Lookup[curveData, "Params", Lookup[config, "Params", <||>]];
  cutoffs = commitmentThetaCutoffs[params];
  If[cutoffs === <||>, Return[ticks]];
  thetaOver = cutoffs["thetaOver"];
  style = Lookup[config, "CurveTickLabelStyle", Directive[Black, FontSize -> 12]];
  tick = {thetaOver, thetaTickLabel["thetaOver", style]};
  minSpacing = Lookup[config, "ThetaOverTickMinSpacing", .055];
  If[ListQ[ticks],
    thinnedTicks = Select[ticks, Abs[#[[1]] - thetaOver] >= minSpacing &];
    SortBy[DeleteDuplicatesBy[Append[thinnedTicks, tick], First], First],
    ticks
  ]
];

thetaOverGuideEpilog[curveData_Association, config_Association] := Module[{params, cutoffs, thetaOver, style},
  If[! TrueQ[Lookup[config, "AddThetaOverTick", False]], Return[{}]];
  params = Lookup[curveData, "Params", Lookup[config, "Params", <||>]];
  cutoffs = commitmentThetaCutoffs[params];
  If[cutoffs === <||>, Return[{}]];
  thetaOver = cutoffs["thetaOver"];
  style = Lookup[config, "ThetaOverGuideStyle", Directive[GrayLevel[.35], AbsoluteThickness[.8], Dotted]];
  {style, Line[{{thetaOver, -10}, {thetaOver, thetaOver}}], Line[{{-10, thetaOver}, {thetaOver, thetaOver}}]}
];

commitmentThetaCutoffs[params_Association] := Module[{m, beta, b, thetaUnder, thetaOver, thetaBreve},
  If[! And @@ (KeyExistsQ[params, #] & /@ {"m", "beta", "b"}), Return[<||>]];
  {m, beta, b} = N[params /@ {"m", "beta", "b"}];
  If[! And @@ (NumericQ /@ {m, beta, b}) || beta == 1, Return[<||>]];
  thetaUnder = 2 beta^2/(1 - beta) (b + 1) m (1/2 + m);
  thetaOver = 2 beta/(1 - beta) (b + 1) m (1 - beta (1/2 + m));
  thetaBreve = beta (1/2 + m (1 + 2 b));
  <|
    "thetaUnder" -> thetaUnder,
    "thetaOver" -> thetaOver,
    "oneMinusThetaOver" -> 1 - thetaOver,
    "thetaBreve" -> thetaBreve,
    "oneMinusThetaBreve" -> 1 - thetaBreve,
    "thetaFirstBestBoundary" -> Max[1 - thetaOver, 1 - thetaBreve]
  |>
];

thetaTickLabel[key_, style_] := Switch[key,
  "thetaUnder", Style[DisplayForm[UnderBarBox["\[Theta]"]], style],
  "thetaOver", Style[DisplayForm[OverscriptBox["\[Theta]", "_"]], style],
  "oneMinusThetaOver", Style[DisplayForm[RowBox[{"1", "-", OverscriptBox["\[Theta]", "_"]}]], style],
  _, Style[key, style]
];

thinTicksBySpacing[ticks_List, minSpacing_?NumericQ] := Module[{sorted, kept = {}, numericKept = {}},
  sorted = SortBy[ticks, First];
  Do[
    If[AllTrue[numericKept, Abs[tick[[1]] - #] >= minSpacing &],
      AppendTo[kept, tick];
      AppendTo[numericKept, tick[[1]]]
    ],
    {tick, sorted}
  ];
  kept
];

curveXTicks[curveData_Association, config_Association] := Module[
  {setting, params, style, minSpacing, cutoffs, specialTicks, numericCandidates, numericTicks, specialPositions},
  setting = Lookup[config, "CurveThetaTicks", Automatic];
  If[curveData["XLabel"] =!= "theta", Return[Automatic]];
  style = Lookup[config, "CurveTickLabelStyle", Directive[Black, FontSize -> 12]];
  If[setting === "Eighths",
    Return[{{0, Style["0", style]}, {1/8, Style["1/8", style]}, {1/4, Style["1/4", style]}, {3/8, Style["3/8", style]}, {1/2, Style["1/2", style]}}]
  ];
  If[setting =!= "CommitmentCutoffsAndQuarters", Return[setting]];
  params = Lookup[curveData, "Params", Lookup[config, "Params", <||>]];
  minSpacing = Lookup[config, "CurveThetaTickMinSpacing", .035];
  cutoffs = commitmentThetaCutoffs[params];
  If[cutoffs === <||>, Return[Automatic]];
  specialTicks = Select[
    {
      {cutoffs["oneMinusThetaOver"], thetaTickLabel["oneMinusThetaOver", style]},
      {cutoffs["thetaUnder"], thetaTickLabel["thetaUnder", style]},
      {cutoffs["thetaOver"], thetaTickLabel["thetaOver", style]}
    },
    0 <= #[[1]] <= 1/2 &
  ];
  specialPositions = If[specialTicks === {}, {}, specialTicks[[All, 1]]];
  numericCandidates = {{0, "0"}, {.125, ".125"}, {.25, ".25"}, {.375, ".375"}, {.5, ".5"}};
  numericTicks = Select[numericCandidates, Function[tick, AllTrue[specialPositions, Abs[tick[[1]] - #] >= minSpacing &]]];
  SortBy[Join[specialTicks, ({#[[1]], Style[#[[2]], style]} & /@ numericTicks)], First]
];

curveParameterText[curveData_Association, config_Association] := Module[{params, style},
  params = Lookup[curveData, "Params", Lookup[config, "Params", <||>]];
  style = Lookup[config, "CurveParameterStyle", Lookup[config, "CurveLegendStyle", Directive[Black, FontSize -> 14]]];
  If[AssociationQ[params] && And @@ (KeyExistsQ[params, #] & /@ {"m", "beta", "b"}),
    Style[
      Row[{
        "m = ", NumberForm[N[params["m"]], {4, 2}, NumberPoint -> "."],
        ",  \[Beta] = ", NumberForm[N[params["beta"]], {4, 2}, NumberPoint -> "."],
        ",  b = ", NumberForm[N[params["b"]], {4, 2}, NumberPoint -> "."]
      }],
      style
    ],
    Nothing
  ]
];

curvePlot[curveData_Association, config_Association, title_String] := Module[{axis, series, labels, styles, legendLabels, yRange, yTicks, xTicks, epilog},
  axis = curveData["Axis"];
  series = curveData["Series"];
  labels = curveSeriesOrder[series, config];
  styles = curveStyleFor[#, config] & /@ labels;
  legendLabels = curveLabelFor[#, config] & /@ labels;
  yRange = curveYRange[curveData, config];
  yTicks = addThetaOverTick[curveYTicks[curveData, config], curveData, config];
  xTicks = addThetaOverTick[curveXTicks[curveData, config], curveData, config];
  epilog = thetaOverGuideEpilog[curveData, config];
  ListLinePlot[
    Table[Transpose[{axis, series[label]}], {label, labels}],
    PlotStyle -> styles,
    PlotLegends -> Placed[
      Column[
        {
          LineLegend[
            styles,
            legendLabels,
            LegendLayout -> "Row",
            LabelStyle -> Lookup[config, "CurveLegendStyle", Directive[Black, FontSize -> 14]],
            LegendMarkerSize -> Lookup[config, "CurveLegendMarkerSize", 24]
          ],
          curveParameterText[curveData, config]
        },
        Alignment -> Center,
        Spacings -> .15
      ],
      Below
    ],
    Frame -> True,
    Axes -> False,
    FrameLabel -> {styledAxisLabel[curveData["XLabel"], config, "CurveAxisLabelStyle"], None},
    FrameStyle -> Lookup[config, "FrameStyle", Black],
    FrameTicksStyle -> Lookup[config, "CurveTickLabelStyle", Directive[Black, FontSize -> 12]],
    FrameTicks -> {{yTicks, None}, {xTicks, None}},
    BaseStyle -> Lookup[config, "PlotBaseStyle", Directive[Black, FontSize -> 12]],
    LabelStyle -> Lookup[config, "PlotBaseStyle", Directive[Black, FontSize -> 12]],
    PlotRange -> {All, yRange},
    Epilog -> epilog,
    ImageSize -> config["ImageSize"],
    ImagePadding -> Lookup[config, "CurveImagePadding", Lookup[config, "PaperFigureImagePadding", All]],
    AspectRatio -> config["AspectRatio"]
  ]
];

noCommitmentCurvePlot[data_Association, config_Association, key_String] := curvePlot[data[key], config, "No commitment"];
commitmentCurvePlot[data_Association, config_Association, key_String] := curvePlot[
  data[key],
  If[key === "CommitmentThetaCurves" && TrueQ[Lookup[config, "CommitmentThetaCurveThetaOverTick", False]],
    Join[config, <|"AddThetaOverTick" -> True|>],
    config
  ],
  "Commitment"
];

regimeTicksFromLabels[labels_List] := If[
  AllTrue[labels, MatchQ[_Rule]],
  labels,
  Thread[Range[Length[labels]] -> labels]
];

styledRegimeTicks[ticks_List, config_Association] := ({#[[1]], Style[#[[2]], Lookup[config, "RegimeTickLabelStyle", Directive[Black, FontSize -> 8]]]} & /@ ticks);

regimeInlineLabels[rd_Association, ticks_List, config_Association] := Module[
  {axis, values, assoc, runs, style},
  axis = rd["Axis"];
  values = rd["Values"];
  assoc = Association[ticks];
  style = Lookup[config, "RegimeInlineLabelStyle", Directive[Black, FontSize -> 8]];
  runs = SplitBy[
    Select[Transpose[{axis, values}], NumericQ[#[[2]]] && KeyExistsQ[assoc, Round[#[[2]]]] &],
    Round[#[[2]]] &
  ];
  Table[
    Inset[
      Framed[
        Style[Lookup[assoc, Round[Mean[run[[All, 2]]]], ""], style],
        Background -> White,
        FrameStyle -> None,
        FrameMargins -> {{1, 1}, {0, 0}}
      ],
      {Mean[run[[All, 1]]], Mean[run[[All, 2]]]},
      Center
    ],
    {run, runs}
  ]
];

regimeStepPlot[data_Association, config_Association, key_String, labels_List] := Module[{rd, ticks, tickLabels, inlineLabels},
  rd = data[key];
  ticks = regimeTicksFromLabels[labels];
  tickLabels = styledRegimeTicks[ticks, config];
  inlineLabels = regimeInlineLabels[rd, ticks, config];
  ListLinePlot[
    Transpose[{rd["Axis"], rd["Values"]}],
    InterpolationOrder -> 0,
    PlotStyle -> Directive[Black, Thick],
    Frame -> True,
    Axes -> False,
    FrameLabel -> {
      styledAxisLabel[rd["XLabel"], config, "RegimeAxisLabelStyle"],
      Style["regime", Lookup[config, "RegimeAxisLabelStyle", Directive[Black, FontSize -> 11]]]
    },
    FrameTicks -> {{tickLabels, None}, {Automatic, None}},
    PlotRange -> All,
    ImageSize -> config["ImageSize"],
    AspectRatio -> .25,
    ImagePadding -> {{70, 20}, {40, 12}},
    Epilog -> inlineLabels
  ]
];

regionTriples[region_Association, gridName_String] := Module[{thetaGrid, bGrid, grid},
  thetaGrid = region["ThetaGrid"]; bGrid = region["BGrid"]; grid = region[gridName];
  Flatten[Table[{thetaGrid[[i]], bGrid[[j]], grid[[i, j]]}, {i, Length[thetaGrid]}, {j, Length[bGrid]}], 1]
];

regionClassCenters[region_Association, class_, stride_Integer : 1] := Module[{thetaGrid, bGrid, grid, step},
  thetaGrid = region["ThetaGrid"]; bGrid = region["BGrid"]; grid = region["ClassGrid"];
  step = Max[1, stride];
  Flatten[
    Table[
      If[Round[grid[[i, j]]] === class && Mod[i + j, step] == 0, {thetaGrid[[i]], bGrid[[j]]}, Nothing],
      {i, Length[thetaGrid]},
      {j, Length[bGrid]}
    ],
    1
  ]
];

regionCellSpacings[region_Association] := Module[{tg = region["ThetaGrid"], bg = region["BGrid"]},
  {
    If[Length[tg] > 1, Min[Differences[tg]], .001],
    If[Length[bg] > 1, Min[Differences[bg]], .001]
  }
];

gridStrideForSpacing[spacing_, dx_, dy_] := Max[1, Ceiling[N[spacing]/Max[Min[dx, dy], 10^-12]]];

nearestGridIndex[grid_List, x_?NumericQ] := Module[{n = Length[grid], step},
  If[n <= 1, Return[1]];
  step = (Last[grid] - First[grid])/(n - 1);
  Clip[Round[(x - First[grid])/step] + 1, {1, n}]
];

regionClassAt[region_Association, x_?NumericQ, y_?NumericQ] := Module[
  {tg = region["ThetaGrid"], bg = region["BGrid"], grid = region["ClassGrid"]},
  Round[grid[[nearestGridIndex[tg, x], nearestGridIndex[bg, y]]]]
];

hatchSegmentsFromSamples[pts_List, mask_List] := Module[{groups},
  groups = SplitBy[Transpose[{pts, mask}], Last];
  Line /@ (#[[All, 1]] & /@ Select[groups, Last[First[#]] === True && Length[#] >= 2 &])
];

verticalHatchPrimitives[region_Association, class_, spacing_, sampleCount_] := Module[
  {tg, bg, xs, ys},
  tg = region["ThetaGrid"]; bg = region["BGrid"];
  xs = Range[First[tg], Last[tg], spacing];
  ys = Subdivide[First[bg], Last[bg], sampleCount];
  Flatten[
    Table[
      With[{pts = ({x, #} & /@ ys)},
        hatchSegmentsFromSamples[pts, (regionClassAt[region, x, #] === class & /@ ys)]
      ],
      {x, xs}
    ],
    1
  ]
];

diagonalHatchPrimitives[region_Association, class_, spacing_, sampleCount_] := Module[
  {tg, bg, slope, interceptSpacing, intercepts, xs},
  tg = region["ThetaGrid"]; bg = region["BGrid"];
  slope = (Last[bg] - First[bg])/(Last[tg] - First[tg]);
  interceptSpacing = spacing Sqrt[1 + slope^2];
  intercepts = Range[First[bg] - slope Last[tg], Last[bg] - slope First[tg], interceptSpacing];
  xs = Subdivide[First[tg], Last[tg], sampleCount];
  Flatten[
    Table[
      With[
        {
          pts = Select[({#, slope # + c} & /@ xs), First[bg] <= #[[2]] <= Last[bg] &]
        },
        hatchSegmentsFromSamples[pts, (regionClassAt[region, #[[1]], #[[2]]] === class & /@ pts)]
      ],
      {c, intercepts}
    ],
    1
  ]
];

regionHatchGraphics[region_Association, config_Association] := Module[
  {hatches, hatchColors, opacity, thickness, spacing, sampleCount, primitives},
  hatches = Lookup[config, "RegionHatches", <||>];
  hatchColors = Lookup[config, "RegionHatchLineColors", <||>];
  opacity = Lookup[config, "RegionHatchOpacity", 1.];
  thickness = Lookup[config, "RegionHatchThickness", .75];
  spacing = Lookup[config, "RegionHatchDataSpacing", .025];
  sampleCount = Lookup[config, "RegionHatchSampleCount", Max[Length[region["ThetaGrid"]], Length[region["BGrid"]]]];
  primitives = KeyValueMap[
    Function[{class, hatch},
      {
        Directive[Lookup[hatchColors, class, classColor[class, config]], Opacity[opacity], AbsoluteThickness[thickness]],
        Switch[hatch,
          "Vertical", verticalHatchPrimitives[region, class, spacing, sampleCount],
          "NorthEast", diagonalHatchPrimitives[region, class, spacing, sampleCount],
          _, {}
        ]
      }
    ],
    hatches
  ];
  Graphics[Flatten[primitives]]
];

classFillColor[z_, config_Association] := Module[{class = Round[z], hatches},
  hatches = Lookup[config, "RegionHatches", <||>];
  If[KeyExistsQ[hatches, class] && ! TrueQ[Lookup[config, "RegionHatchedClassesUseColorFill", False]],
    Lookup[config, "RegionHatchFillColor", White],
    classColor[class, config]
  ]
];

classColor[z_, config_Association] := Lookup[
  Lookup[config, "RegionClassColors", <||>],
  Round[z],
  GrayLevel[.55]
];

legendHatchLines[hatch_, color_, config_Association : <||>] := Module[{opacity, thickness},
  opacity = Lookup[config, "RegionHatchOpacity", 1.];
  thickness = Max[.75, Lookup[config, "RegionHatchThickness", .75]];
  Which[
    hatch === "Vertical",
      {Directive[color, Opacity[opacity], AbsoluteThickness[thickness]], Table[Line[{{x, .10}, {x, .90}}], {x, .22, .82, .2}]},
    hatch === "NorthEast",
      {Directive[color, Opacity[opacity], AbsoluteThickness[thickness]], Table[Line[{{x - .32, .10}, {x + .32, .90}}], {x, .14, .86, .22}]},
    True,
      {}
  ]
];

regionLegendSwatch[class_, config_Association] := Module[
  {hatches, hatchColors, fill, hatch, color, size},
  hatches = Lookup[config, "RegionHatches", <||>];
  hatchColors = Lookup[config, "RegionHatchLineColors", <||>];
  size = Lookup[config, "RegionLegendSwatchSize", {18, 18}];
  hatch = Lookup[hatches, class, None];
  fill = If[hatch === None || TrueQ[Lookup[config, "RegionHatchedClassesUseColorFill", False]],
    classColor[class, config],
    Lookup[config, "RegionHatchFillColor", White]
  ];
  color = Lookup[hatchColors, class, classColor[class, config]];
  Graphics[
    {
      EdgeForm[Directive[Black, AbsoluteThickness[.45]]],
      FaceForm[fill],
      Rectangle[{0, 0}, {1, 1}],
      legendHatchLines[hatch, color, config]
    },
    ImageSize -> size,
    PlotRange -> {{0, 1}, {0, 1}}
  ]
];

bindingLegendSwatch[config_Association : <||>] := Graphics[
  {
    EdgeForm[Directive[Black, AbsoluteThickness[.45]]],
    FaceForm[White],
    Rectangle[{0, 0}, {1, 1}],
    GrayLevel[.28],
    PointSize[.12],
    Point[{{.28, .3}, {.72, .3}, {.28, .7}, {.72, .7}}]
  },
  ImageSize -> Lookup[config, "RegionLegendSwatchSize", {18, 18}],
  PlotRange -> {{0, 1}, {0, 1}}
];

regionLegend[order_, labels_, config_, bindLegend_ : None] := Grid[
  Module[{style, columns, entries, extraRows, rows},
    style = Lookup[config, "RegionLegendStyle", Directive[Black, FontSize -> 12]];
    columns = Lookup[config, "RegionLegendColumns", 1];
    entries = If[bindLegend === None,
      ({regionLegendSwatch[#, config], Style[Lookup[labels, #, ToString[#]], style]} & /@ order),
      Join[
        ({regionLegendSwatch[#, config], Style[Lookup[labels, #, ToString[#]], style]} & /@ order),
        {{bindingLegendSwatch[config], Style[bindLegend, style]}}
      ]
    ];
    extraRows = ({Style[#, style], Sequence @@ ConstantArray[SpanFromLeft, 2 columns - 1]} & /@ Lookup[config, "RegionLegendExtraRows", {}]);
    rows = Partition[entries, UpTo[columns]];
    Join[
      Flatten[Join[#, ConstantArray[{"", ""}, columns - Length[#]]], 1] & /@ rows,
      extraRows
    ]
  ],
  Alignment -> {Left, Center},
  Spacings -> {.55, .35}
];

regionBindingPoints[region_Association, stride_Integer : 1] := Module[
  {thetaGrid, bGrid, grid, step},
  thetaGrid = region["ThetaGrid"]; bGrid = region["BGrid"]; grid = region["PBindGrid"];
  step = Max[1, stride];
  Flatten[
    Table[
      If[Round[grid[[i, j]]] === 1 && Mod[i - 1, step] == 0 && Mod[j - 1, step] == 0, {thetaGrid[[i]], bGrid[[j]]}, Nothing],
      {i, Length[thetaGrid]},
      {j, Length[bGrid]}
    ],
    1
  ]
];

regionPlotFromData[region_Association, config_Association, includeBinding_ : False] := Module[
  {classTriples, pBindPts, base, hatchOverlay, bindOverlay, order, labels, bindLegend, legend, overlayStride, dx, dy, overlaySpacing},
  order = Lookup[config, "RegionClassOrder", {-9, 0, 1, 2, 3, 4}];
  labels = Lookup[config, "RegionClassLabels", <||>];
  bindLegend = If[TrueQ[includeBinding] && KeyExistsQ[region, "PBindGrid"], Lookup[config, "RegionOverlayLabel", "P on-path binding"], None];
  legend = regionLegend[order, labels, config, bindLegend];
  classTriples = regionTriples[region, "ClassGrid"];
  {dx, dy} = regionCellSpacings[region];
  overlaySpacing = Lookup[config, "RegionOverlayDataSpacing", Automatic];
  overlayStride = If[NumericQ[overlaySpacing], gridStrideForSpacing[overlaySpacing, dx, dy], Lookup[config, "RegionOverlayStride", 1]];
  pBindPts = If[bindLegend === None, {}, regionBindingPoints[region, overlayStride]];
  base = ListDensityPlot[
    classTriples,
    InterpolationOrder -> 0,
    ColorFunction -> (classFillColor[#, config] &),
    ColorFunctionScaling -> False,
    Frame -> True,
    FrameLabel -> {
      styledAxisLabel["theta", config, "RegionAxisLabelStyle"],
      styledAxisLabel["b", config, "RegionAxisLabelStyle"]
    },
    FrameStyle -> Lookup[config, "FrameStyle", Black],
    FrameTicksStyle -> Lookup[config, "RegionTickLabelStyle", Directive[Black, FontSize -> 12]],
    BaseStyle -> Lookup[config, "PlotBaseStyle", Directive[Black, FontSize -> 12]],
    LabelStyle -> Lookup[config, "PlotBaseStyle", Directive[Black, FontSize -> 12]],
    PlotLegends -> Placed[legend, Lookup[config, "RegionLegendPlacement", Right]],
    PlotRange -> All,
    ImageSize -> config["ImageSize"],
    ImagePadding -> Lookup[config, "RegionImagePadding", Lookup[config, "PaperFigureImagePadding", {{62, 14}, {56, 14}}]],
    AspectRatio -> config["AspectRatio"]
  ];
  hatchOverlay = regionHatchGraphics[region, config];
  bindOverlay = If[bindLegend === None, Graphics[{}], Graphics[Join[Lookup[config, "RegionOverlayStyle", {Black, Opacity[.6], AbsolutePointSize[1.2]}], {Point[pBindPts]}]]];
  Show[base, hatchOverlay, bindOverlay]
];

regionThetaBPlot[data_Association, config_Association] := regionPlotFromData[data["NoCommitmentRegionThetaB"], config, True];
parameterLegendText[params_Association] := Row[{
  "\[Beta] = ", NumberForm[N[params["beta"]], {4, 2}, NumberPoint -> "."],
  ",  m = ", NumberForm[N[params["m"]], {4, 2}, NumberPoint -> "."]
}];

commitmentRegionThetaBPlot[data_Association, config_Association] := Module[{region, params, cConfig},
  region = data["CommitmentRegionThetaB"];
  params = Lookup[region, "Params", Lookup[data, "Metadata", <||>]["Params"]];
  cConfig = Join[
    config,
    <|
      "RegionClassOrder" -> Lookup[config, "CommitmentRegionClassOrder", {4, 1, 2, 3}],
      "RegionLegendExtraRows" -> {parameterLegendText[params]}
    |>
  ];
  regionPlotFromData[region, cConfig, False]
];

exportGraphicsSet[graphics_Association, config_Association, stem_String] := Module[{dir, written = {}},
  dir = ensureDirectory[config["ExportDir"]];
  KeyValueMap[
    Function[{name, graphic},
      If[TrueQ[config["ExportPDF"]], AppendTo[written, Export[FileNameJoin[{dir, stem <> "_" <> name <> ".pdf"}], graphic, "PDF"]]];
      If[TrueQ[config["ExportWXF"]], AppendTo[written, Export[FileNameJoin[{dir, stem <> "_" <> name <> ".wxf"}], graphic, "WXF"]]];
    ],
    graphics
  ];
  Print["Exported graphics to: ", dir];
  written
];

End[];
EndPackage[];
