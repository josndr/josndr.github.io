# Figure Code Package

This package contains the Wolfram/Mathematica files needed to regenerate the
figure data and export the figure graphics.

Start with `FigureWorkflow_README.md` for the full workflow and requirements.

Quick run:

1. Make sure Wolfram Mathematica or Wolfram Engine is installed and
   `wolframscript` is available if you want to use the command line.
2. Run `Code/GenerateFigureData.nb` from Mathematica Desktop, or run:

   ```powershell
   wolframscript -file Code/GenerateFigureData.wl
   ```

3. Run the plot notebooks or command-line scripts:

   ```powershell
   wolframscript -file Code/NoCommitmentPlots.wl
   wolframscript -file Code/CommitmentPlots.wl
   wolframscript -file Code/RegionPlots.wl
   ```

Outputs are written to `Graphs/generated/` as PDF and WXF files.

The normal workflow uses the included selector caches:

- `Code/partial_nc_selector_cache.mx`
- `Code/partial_nc_selector_cache.wl`

`Code/PartialNonCommitmentCleaner.nb` is included as the no-commitment source
notebook. It only needs to be rerun if the selector definitions must be
refreshed.
